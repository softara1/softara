/* ═══════════════════════════════════════════════════════════════════════
   Softara فهرس — Topic Index   |   v1.0.0
   ─────────────────────────────────────────────────────────────────────
   فهرس تلقائي ذكي داخل المواضيع الطويلة على منتديات أحلى منتدى.

   ماذا يفعل؟
   • يكتشف عناوين الموضوع تلقائيًا (وسوم h2/h3/h4 أو سطر كبير غامق
     مثل [size=18][b]العنوان[/b][/size]) ويبني فهرسًا قابلًا للنقر
     أعلى المشاركة الأولى — دون أي تدخل يدوي.
   • يبرز القسم الحالي أثناء التمرير، ويظهر شريط تقدم القراءة
     ووقت قراءة تقريبي.
   • زر عائم على الهاتف يفتح الفهرس كطبقة سفلية أنيقة.
   • يتكيف تلقائيًا مع الوضع الداكن وألوان استايل Softara Original،
     ويعمل على النسخ الشائعة لأحلى منتدى (مُختبَر فعليًا على AwesomeBB).

   موضع التركيب في لوحة الإدارة:
   عناصر إضافية » إدارة أكواد Javascript » إنشاء كود جديد
   العنوان: Softara فهرس v1.0.0   |   موضع الكود: المواضيع ✔ فقط

   الحقوق: © Softara — https://softara.yoo7.com
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
  "use strict";
  if (window.SoftaraTOC) return;               // حماية من التنفيذ المكرر
  if (!/^\/t\d+(p\d+)?(-|$)/.test(location.pathname)) return;  // صفحات المواضيع فقط
  if (/^\/t\d+p\d+(-|$)/.test(location.pathname)) return;      // لا فهرس في صفحات الإصدار 2+ من الموضوع

  /* ═════════ 1) الإعدادات — عدّل بحرية ═════════ */
  var CONFIG = {
    minHeadings: 2,         // أدنى عدد عناوين لإظهار الفهرس (أقل من ذلك = موضوع قصير لا يحتاج فهرسًا)
    maxItems: 40,           // أقصى عدد عناصر يعرضها الفهرس (حماية من المواضيع الضخمة جدًا)
    maxHeadingChars: 120,   // أقصى طول نص يُقبل عنوانًا (حماية من الالتقاط الخاطئ للفقرات)
    bigFontPx: 16.5,        // أقل حجم خط يُعتبر "سطر عنوان كبير" في الكشف الذكي للنص الغامق
    showNumbers: true,      // ترقيم الأقسام (1، 1.1 ...)
    showReadingTime: true,  // عرض وقت القراءة التقريبي
    readWpm: 150,           // سرعة القراءة العربية التقريبية (كلمة/دقيقة)
    smoothScroll: true,     // تمرير سلس عند النقر
    autoOffset: true,       // قياس ارتفاع الرأس الثابت للمنتدى تلقائيًا
    offset: 84,             // احتياطي بكسل يُستخدم إن فشل القياس التلقائي
    mobileMax: 768,         // عرض الشاشة الذي يُعتبر بعده الجهاز هاتفًا
    collapseOnMobile: true  // إظهار الفهرس مطويًا افتراضيًا على الهاتف
  };

  /* نصوص الواجهة — عربية جاهزة */
  var L = {
    title: "محتويات الموضوع",
    show: "إظهار الفهرس",
    hide: "إخفاء الفهرس",
    copyTip: "تم نسخ رابط القسم",
    minutes1: "دقيقة قراءة تقريبية",
    minutes2: "دقائق قراءة تقريبية",
    more: function (n) { return "و " + n + " قسمًا آخر غير معروض في الفهرس"; }
  };
  function sectionsWord(n) {
    if (n === 1) return "قسم واحد";
    if (n === 2) return "قسمان";
    if (n >= 3 && n <= 10) return n + " أقسام";
    return n + " قسمًا";
  }

  var VERSION = "1.0.0";
  var ID_PREFIX = "so-toc-";

  /* ═════════ 2) النمط — CSS مدمج، يتكيف مع ألوان Softara Original ═════════ */
  var CSS =
".so-toc{--stc-surface:var(--so-surface,#ffffff);--stc-surface-dim:var(--so-surface-dim,#f4f3ee);" +
"--stc-ink:var(--so-ink,#171522);--stc-muted:#6f6a85;--stc-line:var(--so-line,#e6e3db);" +
"--stc-brand:var(--so-brand,#6c4cf1);--stc-brand-hover:var(--so-brand-hover,#5936e4);" +
"--stc-wash:var(--so-brand-wash,#efebff);--stc-radius:var(--so-r-card,14px);" +
"background:var(--stc-surface);border:1px solid var(--stc-line);border-radius:var(--stc-radius);" +
"margin:0 0 18px 0;overflow:hidden;font-family:var(--so-font-body,'IBM Plex Sans Arabic','Alexandria',Tahoma,sans-serif);" +
"color:var(--stc-ink);box-shadow:0 1px 2px rgba(23,20,34,.04),0 4px 14px rgba(23,20,34,.05);" +
"direction:rtl;text-align:right;-webkit-text-size-adjust:100%}" +
".so-toc *,.so-toc-drawer *{box-sizing:border-box;margin:0;padding:0}" +
".so-toc-head{display:flex;align-items:center;gap:10px;padding:12px 16px;cursor:pointer;" +
"user-select:none;-webkit-user-select:none;background:linear-gradient(0deg,rgba(108,76,241,.05),rgba(108,76,241,.05));" +
"border-bottom:1px solid var(--stc-line)}" +
".so-toc-head:focus-visible{outline:2px solid var(--stc-brand);outline-offset:-2px}" +
".so-toc-ic{flex:0 0 auto;width:34px;height:34px;border-radius:10px;background:var(--stc-wash);" +
"color:var(--stc-brand);display:flex;align-items:center;justify-content:center}" +
".so-toc-ic svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;" +
"stroke-linecap:round;stroke-linejoin:round}" +
".so-toc-tt{flex:1 1 auto;min-width:0}" +
".so-toc-tt b{display:block;font-family:var(--so-font-display,'Alexandria','IBM Plex Sans Arabic',sans-serif);" +
"font-size:15.5px;font-weight:700;line-height:1.3;color:var(--stc-ink)}" +
".so-toc-meta{display:flex;flex-wrap:wrap;gap:4px 12px;margin-top:2px;font-size:12px;color:var(--stc-muted)}" +
".so-toc-caret{flex:0 0 auto;width:30px;height:30px;border-radius:8px;border:1px solid var(--stc-line);" +
"background:var(--stc-surface);color:var(--stc-muted);display:flex;align-items:center;justify-content:center;" +
"transition:transform var(--so-t-mid,180ms) var(--so-ease,cubic-bezier(.2,.7,.3,1))}" +
".so-toc-caret svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}" +
".so-toc.is-collapsed .so-toc-caret{transform:rotate(180deg)}" +
".so-toc.is-collapsed .so-toc-head{border-bottom-color:transparent}" +
".so-toc-prog{position:relative;height:3px;background:var(--stc-line);overflow:hidden}" +
".so-toc-prog i{position:absolute;top:0;inset-inline-start:0;height:100%;width:0;" +
"background:linear-gradient(90deg,var(--stc-brand),var(--stc-brand-hover));border-radius:0 2px 2px 0;" +
"transition:width .25s linear}" +
".so-toc.is-collapsed .so-toc-prog{display:none}" +
".so-toc-listwrap{max-height:44vh;overflow:auto;overscroll-behavior:contain;" +
"scrollbar-width:thin;scrollbar-color:var(--stc-line) transparent}" +
".so-toc.is-collapsed .so-toc-listwrap{display:none}" +
".so-toc-list{list-style:none;padding:8px}" +
".so-toc-item{border-radius:8px}" +
".so-toc-link{display:flex;align-items:baseline;gap:8px;padding:8px 10px;border-radius:8px;" +
"color:var(--stc-ink);text-decoration:none!important;font-size:13.8px;line-height:1.55;" +
"transition:background var(--so-t-fast,120ms) ease,color var(--so-t-fast,120ms) ease}" +
".so-toc-link:hover{background:var(--stc-surface-dim);color:var(--stc-brand-hover)}" +
".so-toc-link:focus-visible{outline:2px solid var(--stc-brand);outline-offset:-2px}" +
".so-toc-link.is-active{background:var(--stc-wash);color:var(--stc-brand-hover);font-weight:600}" +
".so-toc-link.is-active .so-toc-num{color:var(--stc-brand)}" +
".so-toc-num{flex:0 0 auto;min-width:20px;font-family:var(--so-font-mono,'JetBrains Mono',monospace);" +
"font-size:11.5px;font-weight:600;color:var(--stc-muted);direction:ltr;text-align:left}" +
".so-toc-txt{flex:1 1 auto;min-width:0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;" +
"overflow:hidden}" +
".so-l2 .so-toc-link{padding-inline-start:26px}" +
".so-l3 .so-toc-link{padding-inline-start:44px}" +
".so-l3 .so-toc-num{min-width:14px}" +
".so-toc-more{padding:8px 12px 10px;font-size:11.5px;color:var(--stc-muted);text-align:center}" +
".so-toc-anchor{display:inline-flex;width:17px;height:17px;margin-inline-start:7px;vertical-align:middle;" +
"border-radius:5px;color:var(--stc-brand);opacity:0;transition:opacity var(--so-t-fast,120ms) ease;" +
"cursor:pointer;background:transparent;border:0;padding:0;align-items:center;justify-content:center}" +
".so-toc-anchor svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round}" +
".so-has-anchor:hover .so-toc-anchor,.so-toc-anchor:focus-visible{opacity:.85}" +
".so-has-anchor{scroll-margin-top:96px}" +
"@media (hover:none){.so-toc-anchor{opacity:.45}}" +
".so-toc-fab{position:fixed;bottom:18px;inset-inline-start:14px;z-index:9990;width:52px;height:52px;" +
"border-radius:16px;border:1px solid var(--stc-line);background:var(--stc-surface);color:var(--stc-brand);" +
"box-shadow:0 6px 20px rgba(23,20,34,.18);display:none;align-items:center;justify-content:center;cursor:pointer;" +
"padding:0;transform:translateY(12px);opacity:0;transition:opacity var(--so-t-mid,180ms) ease,transform var(--so-t-mid,180ms) ease}" +
".so-toc-fab.is-on{display:flex;transform:translateY(0);opacity:1}" +
".so-toc-fab svg{width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}" +
".so-toc-drawer{position:fixed;inset:0;z-index:9995;display:none}" +
".so-toc-drawer.is-open{display:block}" +
".so-toc-drawer .so-toc-bd{position:absolute;inset:0;background:rgba(13,12,20,.55);opacity:0;" +
"transition:opacity var(--so-t-mid,180ms) ease}" +
".so-toc-drawer.is-in .so-toc-bd{opacity:1}" +
".so-toc-drawer .so-toc-panel{position:absolute;inset-inline:0;bottom:0;max-height:76vh;display:flex;" +
"flex-direction:column;background:var(--stc-surface,#fff);border-radius:18px 18px 0 0;" +
"transform:translateY(100%);transition:transform var(--so-t-slow,240ms) var(--so-ease,cubic-bezier(.2,.7,.3,1));" +
"color:var(--stc-ink,#171522);font-family:var(--so-font-body,'IBM Plex Sans Arabic',Tahoma,sans-serif);direction:rtl;text-align:right}" +
".so-toc-drawer.is-in .so-toc-panel{transform:translateY(0)}" +
".so-toc-drawer .so-toc-grab{width:44px;height:4px;border-radius:99px;background:var(--stc-line,#e6e3db);margin:10px auto 2px}" +
".so-toc-drawer .so-toc-dhead{display:flex;align-items:center;gap:10px;padding:8px 18px 12px;" +
"border-bottom:1px solid var(--stc-line,#e6e3db)}" +
".so-toc-drawer .so-toc-dhead b{flex:1;font-size:15px}" +
".so-toc-drawer .so-toc-dclose{width:32px;height:32px;border-radius:9px;border:1px solid var(--stc-line,#e6e3db);" +
"background:transparent;color:inherit;display:flex;align-items:center;justify-content:center;cursor:pointer}" +
".so-toc-drawer .so-toc-dclose svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round}" +
".so-toc-drawer .so-toc-listwrap{max-height:60vh;flex:1}" +
".so-toc-toast{position:fixed;bottom:86px;left:50%;transform:translate(-50%,8px);z-index:9999;" +
"background:var(--so-bar-bg,rgba(23,20,34,.92));color:var(--so-bar-ink,#f2f0fa);padding:9px 16px;" +
"border-radius:99px;font-size:13px;font-family:var(--so-font-body,'IBM Plex Sans Arabic',Tahoma,sans-serif);" +
"opacity:0;pointer-events:none;transition:opacity var(--so-t-mid,180ms) ease,transform var(--so-t-mid,180ms) ease}" +
".so-toc-toast.is-on{opacity:1;transform:translate(-50%,0)}" +
"@media (max-width:768px){" +
".so-toc-listwrap{max-height:none;overflow:visible}" +
".so-toc-fab{bottom:16px;inset-inline-start:12px}" +
"}" +
"@media print{.so-toc-fab,.so-toc-drawer,.so-toc-caret{display:none!important}" +
".so-toc{box-shadow:none;break-inside:avoid}}";

  function injectCSS() {
    var st = document.createElement("style");
    st.id = "so-toc-style";
    st.textContent = CSS;
    document.head.appendChild(st);
  }

  /* ═════════ 3) أدوات مساعدة ═════════ */
  var SVG = {
    list: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r=".9" fill="currentColor" stroke="none"/><circle cx="3.5" cy="12" r=".9" fill="currentColor" stroke="none"/><circle cx="3.5" cy="18" r=".9" fill="currentColor" stroke="none"/></svg>',
    caret: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 15l-6-6-6 6"/></svg>',
    link: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 13a5 5 0 007.5.5l3-3a5 5 0 00-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 00-7.5-.5l-3 3a5 5 0 007 7L12.2 19"/></svg>',
    close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 6L6 18M6 6l12 12"/></svg>'
  };

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function svgWrap(name) {
    var s = el("span");
    s.innerHTML = SVG[name];         // سلاسل ثابتة داخل الكود فقط — آمن
    return s.firstChild;
  }
  function normText(t) {
    return (t || "").replace(/\s+/g, " ").trim();
  }
  function isHidden(n) {
    return !(n.offsetWidth || n.offsetHeight || n.getClientRects().length);
  }

  /* ═════════ 4) كشف العناوين ═════════ */
  var EXCLUDE_SEL =
    "blockquote,.codebox,dl.codebox,pre,.spoiler,.spoiler_content,.quote,.signature," +
    ".signature_div,.post-signature,.attachbox,.fa_like_div,.profile-icons,.polls," +
    ".fa_vote,.contact-element,.post-buttons,.mobile-show";

  function findContent() {
    var cands = [
      ".post-wrap .post-content",   /* AwesomeBB */
      ".postbody .content",         /* phpBB3 / punBB / ModernBB */
      ".postbody .post-entry",      /* Invision */
      "div.postbody",               /* phpBB3 بديل */
      "span.postbody"               /* phpBB2 */
    ];
    for (var i = 0; i < cands.length; i++) {
      var n = document.querySelector(cands[i]);
      if (n && !isHidden(n)) return n;
    }
    return null;
  }

  function inExcluded(n, root) {
    return !!(n.closest && n.closest(EXCLUDE_SEL) && root.contains(n.closest(EXCLUDE_SEL)));
  }

  /* هل العنصر الغامق يشغل السطر بمفرده؟ — نقيس نص «السطر البصري»:
     أبناء أقرب كتلة مقسومين بفواصل <br> — فوسوم التنسيق السطرية لا تصنع سطرًا،
     والنص الوسيط داخل فقرة يرفض الالتقاط */
  function isInlineEl(n) {
    if (!n || n.nodeType !== 1) return true;
    var tag = n.tagName;
    if (tag === "SPAN" || tag === "A" || tag === "STRONG" || tag === "B" ||
        tag === "EM" || tag === "I" || tag === "U" || tag === "FONT" || tag === "SMALL") {
      var disp = getComputedStyle(n).display;
      return disp === "inline" || disp === "inline-block" || disp === "none";
    }
    return false;
  }
  function lineTextOf(node, root) {
    var block = node;
    while (block && block !== root && isInlineEl(block)) block = block.parentElement;
    if (!block || block === root) block = root;
    var line = [], seen = false, kids = block.childNodes;
    for (var i = 0; i < kids.length; i++) {
      var k = kids[i];
      /* فاصل السطر: وسم <br> أو أي عنصر كتلي إخوة */
      var isBreak = k.nodeType === 1 && (k.tagName === "BR" || !isInlineEl(k));
      if (isBreak) {
        if (seen) break;
        line = [];
        continue;
      }
      line.push(k);
      if (k === node || (k.nodeType === 1 && k.contains(node))) seen = true;
    }
    var txt = "";
    for (var j = 0; j < line.length; j++) txt += line[j].textContent || "";
    return normText(txt);
  }
  function ownsItsLine(strong, root) {
    var t = normText(strong.textContent);
    if (!t) return false;
    return lineTextOf(strong, root) === t;
  }

  function collectHeadings(root) {
    var found = [], seen = [];

    /* الطبقة 1: وسوم عناوين حقيقية */
    var tags = root.querySelectorAll("h2,h3,h4");
    for (var i = 0; i < tags.length; i++) {
      var h = tags[i];
      if (isHidden(h) || inExcluded(h, root)) continue;
      var t = normText(h.textContent);
      if (t.length < 2 || t.length > CONFIG.maxHeadingChars) continue;
      var lvl = h.tagName === "H2" ? 1 : (h.tagName === "H3" ? 2 : 3);
      found.push({ node: h, level: lvl, text: t });
      seen.push(h);
    }

    /* الطبقة 2: سطر غامق كبير ([size=18][b]العنوان[/b][/size] وما يشبهه) */
    var strongs = root.querySelectorAll("strong,b");
    for (var j = 0; j < strongs.length; j++) {
      var s = strongs[j];
      if (isHidden(s) || inExcluded(s, root)) continue;
      if (s.closest && s.closest("h1,h2,h3,h4,h5,h6")) continue;   /* داخل عنوان حقيقي — احتُسب سابقًا */
      var txt = normText(s.textContent);
      if (txt.length < 2 || txt.length > CONFIG.maxHeadingChars) continue;
      if (s.querySelector("a,img")) continue;                       /* روابط/صور = ليست عنوانًا */
      if (!ownsItsLine(s, root)) continue;                          /* يجب أن يشغل السطر كاملًا */
      var fs = parseFloat(getComputedStyle(s).fontSize) || 0;
      if (fs < CONFIG.bigFontPx) continue;                          /* يجب أن يكون كبيرًا بصريًا */
      var dup = false;
      for (var k = 0; k < seen.length; k++) if (seen[k] === s || seen[k].contains(s)) { dup = true; break; }
      if (dup) continue;
      found.push({ node: s, level: 1, text: txt });
      seen.push(s);
    }

    /* الترتيب بموضع المستند ثم تطبيع المستويات (إن بدأ الموضوع بـ h3 دون h2) */
    found.sort(function (a, b) {
      return a.node.compareDocumentPosition(b.node) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
    });
    if (found.length) {
      var minL = found[0].level;
      for (var m = 1; m < found.length; m++) if (found[m].level < minL) minL = found[m].level;
      if (minL > 1) for (var s = 0; s < found.length; s++) found[s].level -= (minL - 1);
    }
    /* إسناد معرف رابط ثابت لكل عنوان (يحفظ المعرف الأصلي إن وُجد) */
    for (var w = 0; w < found.length; w++) {
      var aid = found[w].node.id || (ID_PREFIX + w);
      found[w].node.id = aid;
      found[w].anchorId = aid;
    }
    return found;
  }

  /* ═════════ 5) بناء بطاقة الفهرس ═════════ */
  function buildList(items, startIdx, isDrawer) {
    var ol = el("ol", "so-toc-list");
    var n1 = 0, n2 = 0;
    var limit = Math.min(items.length, CONFIG.maxItems);
    for (var i = startIdx || 0; i < limit; i++) {
      (function (it, idx) {
        var li = el("li", "so-toc-item so-l" + it.level);
        var a = el("a", "so-toc-link");
        a.href = "#" + it.anchorId;
        a.setAttribute("data-idx", String(idx));
        a.setAttribute("role", "button");
        if (isDrawer) a.setAttribute("data-drawer", "1");
        var num = el("span", "so-toc-num");
        if (CONFIG.showNumbers) {
          if (it.level === 1) { n1++; n2 = 0; num.textContent = n1 + "."; }
          else if (it.level === 2) { n2++; num.textContent = n1 + "." + n2; }
          else num.textContent = "–";
        }
        var tx = el("span", "so-toc-txt", it.text);   /* نصContent فقط — آمن */
        tx.title = it.text;
        a.appendChild(num);
        a.appendChild(tx);
        li.appendChild(a);
        ol.appendChild(li);
      })(items[i], i);
    }
    return ol;
  }

  function buildCard(items, info) {
    var card = el("nav", "so-toc");
    card.id = "softara-toc";
    card.setAttribute("aria-label", L.title);

    var head = el("div", "so-toc-head");
    head.setAttribute("role", "button");
    head.setAttribute("tabindex", "0");
    head.setAttribute("aria-expanded", "true");

    var ic = el("span", "so-toc-ic");
    ic.appendChild(svgWrap("list"));
    var tt = el("div", "so-toc-tt");
    var b = el("b", null, L.title);
    var meta = el("div", "so-toc-meta");
    var mSec = el("span", null, sectionsWord(items.length));
    meta.appendChild(mSec);
    if (CONFIG.showReadingTime && info.minutes) {
      meta.appendChild(el("span", null, "•"));
      meta.appendChild(el("span", null, info.minutes + " " + (info.minutes > 10 ? L.minutes1 : (info.minutes > 1 ? L.minutes2 : L.minutes1))));
    }
    tt.appendChild(b); tt.appendChild(meta);
    var caret = el("span", "so-toc-caret");
    caret.appendChild(svgWrap("caret"));
    head.appendChild(ic); head.appendChild(tt); head.appendChild(caret);

    var prog = el("div", "so-toc-prog");
    var bar = el("i"); prog.appendChild(bar);

    var listwrap = el("div", "so-toc-listwrap");
    var list = buildList(items, 0, false);
    listwrap.appendChild(list);
    if (items.length > CONFIG.maxItems) {
      listwrap.appendChild(el("div", "so-toc-more", L.more(items.length - CONFIG.maxItems)));
    }

    card.appendChild(head); card.appendChild(prog); card.appendChild(listwrap);
    return { card: card, head: head, bar: bar, listwrap: listwrap, list: list };
  }

  /* ═════════ 6) السلوك: تمرير، تتبع، تقدم ═════════ */
  function scrollOffset() {
    if (!CONFIG.autoOffset) return CONFIG.offset;
    var off = 0, top = 0;
    var nodes = document.querySelectorAll("body *");
    for (var i = 0; i < nodes.length; i++) {
      var cs = getComputedStyle(nodes[i]);
      if ((cs.position === "fixed" || cs.position === "sticky") && !nodes[i].closest(".so-toc,.so-toc-drawer")) {
        var r = nodes[i].getBoundingClientRect();
        if (r.top <= 1 && r.bottom > 0 && r.height > 20 && r.height < 220) {
          var bottom = r.bottom;
          if (bottom > off && bottom > top) off = bottom;
        }
      }
      if (i > 400) break;   /* حد أقصى للفحص — أداء */
    }
    return Math.max(off, CONFIG.offset);
  }

  function attachBehavior(ctx, items, content) {
    var offset = scrollOffset();
    var isMobile = function () { return window.innerWidth <= CONFIG.mobileMax; };
    var ticking = false;

    function setActive(idx) {
      var target = "#" + (items[idx] ? items[idx].anchorId : ID_PREFIX + idx);
      var links = ctx.card.querySelectorAll(".so-toc-link");
      for (var i = 0; i < links.length; i++) {
        var on = links[i].getAttribute("href") === target;
        links[i].classList.toggle("is-active", on);
        if (on) {
          var li = links[i].parentElement, lw = ctx.listwrap;
          var top = li.offsetTop, bot = top + li.offsetHeight;
          if (top < lw.scrollTop + 8) lw.scrollTop = top - 8;
          else if (bot > lw.scrollTop + lw.clientHeight - 8) lw.scrollTop = bot - lw.clientHeight + 8;
        }
      }
      if (drawerList) {
        var dlinks = drawerList.querySelectorAll(".so-toc-link");
        for (var d = 0; d < dlinks.length; d++) {
          dlinks[d].classList.toggle("is-active", dlinks[d].getAttribute("href") === target);
        }
      }
    }

    function onScroll() {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        ticking = false;
        var best = -1;
        for (var i = 0; i < items.length && i < CONFIG.maxItems; i++) {
          var r = items[i].node.getBoundingClientRect();
          if (r.top <= offset + 16) best = i;
          else break;
        }
        setActive(best < 0 ? 0 : best);

        /* التقدم: نسبة ما تجاوزه أسفل الشاشة داخل المشاركة الأولى */
        var cr = content.getBoundingClientRect();
        var vh = window.innerHeight || 1;
        var p = (vh - cr.top) / Math.max(cr.height, 1);
        p = Math.max(0, Math.min(1, p));
        ctx.bar.style.width = (p * 100).toFixed(1) + "%";

        /* الزر العائم: يظهر بعد تجاوز البطاقة */
        if (isMobile() && fab) {
          var fr = ctx.card.getBoundingClientRect();
          fab.classList.toggle("is-on", fr.bottom < 0 && drawer && !drawer.classList.contains("is-open"));
        }
      });
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", function () {
      offset = scrollOffset();
      onScroll();
    }, { passive: true });

    /* النقر: تمرير سلس إلى القسم */
    function goTo(idx, link) {
      var it = items[idx];
      if (!it) return;
      var top = it.node.getBoundingClientRect().top + window.pageYOffset - offset - 8;
      window.scrollTo({ top: top, behavior: CONFIG.smoothScroll ? "smooth" : "auto" });
      if (history.replaceState) history.replaceState(null, "", "#" + it.anchorId);
      setActive(idx);
    }
    ctx.card.addEventListener("click", function (e) {
      var a = e.target.closest ? e.target.closest(".so-toc-link") : null;
      if (a) {
        e.preventDefault();
        goTo(parseInt(a.getAttribute("data-idx"), 10) || 0, a);
        return;
      }
      if (e.target.closest(".so-toc-head")) toggle();
    });
    ctx.card.addEventListener("keydown", function (e) {
      if (e.target.closest && e.target.closest(".so-toc-head") && (e.key === "Enter" || e.key === " ")) {
        e.preventDefault(); toggle();
      }
    });

    /* الطي والفتح + حفظ الحالة لكل موضوع */
    var tid = (location.pathname.match(/\/t(\d+)/) || [])[1] || "x";
    var storeKey = "softaraTocCollapsed:" + tid;
    function setCollapsed(c) {
      ctx.card.classList.toggle("is-collapsed", c);
      ctx.head.setAttribute("aria-expanded", String(!c));
      try { localStorage.setItem(storeKey, c ? "1" : "0"); } catch (err) {}
    }
    function toggle() { setCollapsed(!ctx.card.classList.contains("is-collapsed")); }
    try {
      if (localStorage.getItem(storeKey) === "1") setCollapsed(true);
      else if (isMobile() && CONFIG.collapseOnMobile) setCollapsed(true);
    } catch (err) { if (isMobile() && CONFIG.collapseOnMobile) ctx.card.classList.add("is-collapsed"); }

    /* روابط العمق: #so-toc-N أو أي معرف عنوان */
    function handleHash() {
      var h = decodeURIComponent(location.hash.slice(1));
      if (!h) return;
      var idx = -1;
      for (var i = 0; i < items.length; i++) if (items[i].anchorId === h) { idx = i; break; }
      if (idx < 0) return;
      setCollapsed(false);
      setTimeout(function () { goTo(idx); }, 350);
    }
    window.addEventListener("hashchange", handleHash);
    handleHash();

    /* الزر العائم + الطبقة السفلية (هاتف) */
    var fab = null, drawer = null, drawerList = null;
    if ("ontouchstart" in window || isMobile()) {
      fab = el("button", "so-toc-fab");
      fab.type = "button";
      fab.setAttribute("aria-label", L.title);
      fab.appendChild(svgWrap("list"));
      document.body.appendChild(fab);

      drawer = el("div", "so-toc-drawer");
      var bd = el("div", "so-toc-bd");
      var panel = el("div", "so-toc-panel");
      var grab = el("div", "so-toc-grab");
      var dhead = el("div", "so-toc-dhead");
      var db = el("b", null, L.title);
      var dmeta = el("span", null, sectionsWord(Math.min(items.length, CONFIG.maxItems)));
      dmeta.style.cssText = "font-size:12px;color:var(--stc-muted,#6f6a85);font-weight:400";
      var dclose = el("button", "so-toc-dclose");
      dclose.type = "button";
      dclose.setAttribute("aria-label", L.hide);
      dclose.appendChild(svgWrap("close"));
      dhead.appendChild(db); dhead.appendChild(dmeta); dhead.appendChild(dclose);
      var dwrap = el("div", "so-toc-listwrap");
      drawerList = buildList(items, 0, true);
      dwrap.appendChild(drawerList);
      panel.appendChild(grab); panel.appendChild(dhead); panel.appendChild(dwrap);
      drawer.appendChild(bd); drawer.appendChild(panel);
      document.body.appendChild(drawer);

      function openDrawer() {
        drawer.classList.add("is-open");
        requestAnimationFrame(function () { requestAnimationFrame(function () { drawer.classList.add("is-in"); }); });
        fab.classList.remove("is-on");
      }
      function closeDrawer() {
        drawer.classList.remove("is-in");
        setTimeout(function () { drawer.classList.remove("is-open"); fab.classList.add("is-on"); }, 240);
      }
      fab.addEventListener("click", openDrawer);
      bd.addEventListener("click", closeDrawer);
      dclose.addEventListener("click", closeDrawer);
      drawerList.addEventListener("click", function (e) {
        var a = e.target.closest ? e.target.closest(".so-toc-link") : null;
        if (!a) return;
        e.preventDefault();
        closeDrawer();
        var idx = parseInt(a.getAttribute("data-idx"), 10) || 0;
        setTimeout(function () { goTo(idx); }, 120);
      });
    }

    /* أيقونة رابط القسم بجانب كل عنوان + نسخ الرابط */
    items.forEach(function (it, idx) {
      if (idx >= CONFIG.maxItems) return;
      var node = it.node;
      node.classList.add("so-has-anchor");
      var an = el("button", "so-toc-anchor");
      an.type = "button";
      an.setAttribute("aria-label", "نسخ رابط القسم");
      an.appendChild(svgWrap("link"));
      an.addEventListener("click", function (e) {
        e.preventDefault(); e.stopPropagation();
        var url = location.origin + location.pathname + "#" + it.anchorId;
        var done = function () {
          if (history.replaceState) history.replaceState(null, "", "#" + it.anchorId);
          toast(L.copyTip);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(url).then(done, function () { fallbackCopy(url); done(); });
        } else fallbackCopy(url), done();
      });
      node.appendChild(an);
    });

    function fallbackCopy(text) {
      try {
        var ta = document.createElement("textarea");
        ta.value = text; ta.style.cssText = "position:fixed;opacity:0";
        document.body.appendChild(ta); ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
      } catch (err) {}
    }

    var toastEl = null, toastTimer = 0;
    function toast(msg) {
      if (!toastEl) { toastEl = el("div", "so-toc-toast"); document.body.appendChild(toastEl); }
      toastEl.textContent = msg;
      toastEl.classList.add("is-on");
      clearTimeout(toastTimer);
      toastTimer = setTimeout(function () { toastEl.classList.remove("is-on"); }, 1800);
    }

    onScroll();
    /* إعادة القياس بعد تحميل الصور داخل الموضوع */
    window.addEventListener("load", onScroll);
  }

  /* ═════════ 7) الإقلاع ═════════ */
  function init() {
    var content = findContent();
    if (!content) return;
    var items = collectHeadings(content);
    if (items.length < CONFIG.minHeadings) return;   /* لا عناوين كافية → لا فهرس (موضوع قصير/عادي) */

    var words = normText(content.textContent).split(" ").filter(Boolean).length;
    var minutes = Math.max(1, Math.round(words / Math.max(CONFIG.readWpm, 60)));

    injectCSS();
    var ctx = buildCard(items, { minutes: minutes });
    content.insertBefore(ctx.card, content.firstChild);

    /* نص أسفل المشاركة عند تجاوز السقف */
    attachBehavior(ctx, items, content);
    window.SoftaraTOC = { version: VERSION, items: items.length, config: CONFIG };
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
