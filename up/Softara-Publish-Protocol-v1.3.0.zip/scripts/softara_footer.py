#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
softara_footer.py — مولّد شريط حقوق سوفتارا القياسي (مرجع إلزامي لكل صورة مستقبلية)
القاعدة المعتمدة (أمر المالك 2026-10-19):
  - الاسم «Softara | احترافيات سوفتارا» في الجهة اليمنى
  - الرابط softara.yoo7.com في الجهة اليسرى
الخط: Cairo Bold للعربية واللاتينية (ملفات محلية — بلا إنترنت)
التصيير: PIL + libraqm (تشكيل عربي حقيقي واتجاه RTL)
"""
from PIL import Image, ImageDraw, ImageFont
import os

# التدرج المقيس من الصور المعتمدة (90°): بنفسجي → أزرق
GRAD = [(91, 46, 229), (120, 73, 251), (84, 142, 250)]  # x=0 / x=52% / x=100%
BAND_H = 62
MARGIN_L = 42          # هامش الرابط من اليسار
MARGIN_R = 43          # هامش الشارة من اليمين
FONT_DIR = os.environ.get("SOFTARA_FONTS", os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts"))
FONT_BOLD = os.path.join(FONT_DIR, "Cairo-Bold.ttf")

BRAND = "احترافيات سوفتارا | Softara"   # المنطقي — يُعرض: Softara | احترافيات سوفتارا
URL = "softara.yoo7.com"

def _gradient_row(w):
    row = []
    for x in range(w):
        t = x / max(1, w - 1)
        if t <= 0.52:
            k = t / 0.52
            a, b = GRAD[0], GRAD[1]
        else:
            k = (t - 0.52) / 0.48
            a, b = GRAD[1], GRAD[2]
        row.append(tuple(round(a[i] + (b[i] - a[i]) * k) for i in range(3)))
    return row

def render_band(width, band_h=BAND_H, font_px=27):
    """يعيد صورة RGB للشريط بالقاعدة المعتمدة (الاسم يمين / الرابط يسار)"""
    img = Image.new("RGB", (width, band_h))
    row = _gradient_row(width)
    d = ImageDraw.Draw(img)
    for x, c in enumerate(row):
        d.line([(x, 0), (x, band_h)], fill=c)
    fnt = ImageFont.truetype(FONT_BOLD, font_px)
    # الرابط يساراً
    bb = d.textbbox((0, 0), URL, font=fnt)
    uy = (band_h - (bb[3] - bb[1])) // 2 - bb[1]
    d.text((MARGIN_L - bb[0], uy), URL, font=fnt, fill=(255, 255, 255))
    # الاسم يميناً (rtl + محاذاة الحافة اليمنى إلى width - MARGIN_R)
    bb2 = d.textbbox((0, 0), BRAND, font=fnt, direction="rtl")
    bw = bb2[2] - bb2[0]
    by = (band_h - (bb2[3] - bb2[1])) // 2 - bb2[1]
    d.text((width - MARGIN_R - bw - bb2[0], by), BRAND, font=fnt, fill=(255, 255, 255), direction="rtl")
    return img

if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "band_test.png"
    render_band(1200).save(out)
    print("band saved:", out)
