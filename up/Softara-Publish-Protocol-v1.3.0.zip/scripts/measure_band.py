#!/usr/bin/env python3
"""قياس هندسي دقيق لشريط الحقوق في صور t928 الأربع"""
from PIL import Image
import json

OUT = "/home/z/my-project/scripts/t928_fix"

def analyze(name):
    im = Image.open(f"{OUT}/orig/{name}.png").convert("RGB")
    w, h = im.size
    # 1) إيجاد الشريط البنفسجي: صف يبدأ بتشبع أزرق/بنفسجي عالٍ
    def is_band(px):
        r, g, b = px
        return b > 150 and r > 50 and r < 180 and g < 180 and (b - g) > 60
    band_rows = []
    for y in range(h - 130, h):
        row = [im.getpixel((x, y)) for x in range(0, w, max(1, w // 40))]
        cnt = sum(1 for p in row if is_band(p))
        if cnt > len(row) * 0.7:
            band_rows.append(y)
    top, bot = min(band_rows), max(band_rows)
    # 2) فحص التدرج الرأسي (عند عمود خالٍ من النص)
    xs = [int(w * 0.62), int(w * 0.30)]
    vert = {}
    for x in xs:
        cols = [im.getpixel((x, y)) for y in range(top + 3, bot - 2)]
        avg = tuple(round(sum(c[i] for c in cols) / len(cols)) for i in range(3))
        var = max(max(c[i] for c in cols) - min(c[i] for c in cols) for i in range(3))
        vert[x] = {"avg": avg, "max_channel_var": var}
    # 3) التدرج الأفقي من صف خالٍ من النص (أعلى الشريط +2)
    ys = top + 2
    grad = [im.getpixel((x, ys)) for x in range(0, w, 8)]
    # 4) حدود النصوص: بكسلات فاتحة (أبيض) داخل الشريط
    def is_text(px):
        r, g, b = px
        return r > 210 and g > 210 and b > 235
    boxes = []
    run = None
    for x in range(w):
        has = any(is_text(im.getpixel((x, y))) for y in range(top + 4, bot - 3))
        if has and run is None:
            run = x
        elif not has and run is not None:
            boxes.append((run, x - 1))
            run = None
    if run is not None:
        boxes.append((run, w - 1))
    # دمج الفجوات < 40px
    merged = []
    for b in boxes:
        if merged and b[0] - merged[-1][1] < 40:
            merged[-1] = [merged[-1][0], b[1]]
        else:
            merged.append(list(b))
    # ارتفاع النص داخل كل صندوق
    result = {"size": [w, h], "band": [int(top), int(bot)], "band_h": int(bot - top + 1),
              "vertical_gradient_check": vert, "text_boxes_x": merged}
    for m in merged:
        y0, y1 = None, None
        for y in range(top + 2, bot - 1):
            if any(is_text(im.getpixel((x, y))) for x in range(m[0], m[1] + 1)):
                if y0 is None: y0 = y
                y1 = y
        m.append((y0, y1))
    print(name, json.dumps(result, ensure_ascii=False))
    return result

allr = {}
for n in ["cover", "fig1", "fig2", "fig3"]:
    allr[n] = analyze(n)
json.dump(allr, open(f"{OUT}/qa/band_analysis.json", "w"), indent=2)
