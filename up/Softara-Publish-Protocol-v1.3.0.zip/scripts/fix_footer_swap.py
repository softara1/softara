#!/usr/bin/env python3
"""
تصحيح موضع الحقوق في صور t928 الأربع — تبديل موضعين فقط ببكسلات حرفية:
  الاسم (Softara | احترافيات سوفتارا) → الجهة اليمنى
  الرابط (softara.yoo7.com)          → الجهة اليسرى
الخط/الحجم/اللون/التدرج/الموضع الرأسي كلها تبقى كما هي حرفيًا (استخراج ألفا + إعادة تركيب).
"""
from PIL import Image
import numpy as np, json, hashlib, os

OUT = "/home/z/my-project/scripts/t928_fix"
FIXED = f"{OUT}/fixed"
os.makedirs(FIXED, exist_ok=True)

BANDS = {"cover": (706, 767), "fig1": (498, 559), "fig2": (498, 559), "fig3": (498, 559)}
# صناديق النص (بإتساع) — مقاسة من 03_measure وتوسعت 6px أفقياً
BOXES = {
    "cover": {"brand": (36, 275, 724, 752), "url": (1121, 1307, 723, 750)},
    "fig1":  {"brand": (36, 275, 516, 548), "url": (977, 1163, 515, 547)},
    "fig2":  {"brand": (36, 275, 516, 548), "url": (977, 1163, 515, 547)},
    "fig3":  {"brand": (36, 275, 516, 548), "url": (977, 1163, 515, 547)},
}
MARGIN_L, MARGIN_R = 42, 43  # كما هي في الأصل

def extract_alpha(arr, box, prof):
    """استخراج قناع ألفا للنص الأبيض فوق التدرج: p = bg(1-a) + 255a"""
    x0, x1, y0, y1 = box
    sub = arr[y0:y1 + 1, x0:x1 + 1, :].astype(float)
    bg = prof[x0:x1 + 1, :][None, :, :]
    # القنوات R,G فقط (حساسية أعلى — قناة B قريبة من 255)
    num = (sub[:, :, :2] - bg[:, :, :2])
    den = (255.0 - bg[:, :, :2])
    a = np.clip(num / np.maximum(den, 30), 0, 1).mean(axis=2)
    return a  # (h, w)

def recomposite(canvas, alpha, x0, y0):
    """تركيب النص (أبيض) بقناع ألفا على الموضع الجديد"""
    h, w = alpha.shape
    region = canvas[y0:y0 + h, x0:x0 + w, :].astype(float)
    a3 = alpha[:, :, None]
    region = region * (1 - a3) + 255.0 * a3
    canvas[y0:y0 + h, x0:x0 + w, :] = np.clip(region, 0, 255).astype(np.uint8)

report = {}
for name, (bt, bb) in BANDS.items():
    im = Image.open(f"{OUT}/orig/{name}.png").convert("RGB")
    arr = np.asarray(im).copy()
    H, W = arr.shape[:2]
    bx = BOXES[name]

    # 1) ملف التدرج الأفقي من صفوف الشريط الخالية من النص (أعلى الشريط)
    prof = arr[bt + 1:bt + 5, :, :].astype(float).mean(axis=0)  # (W,3)

    # 2) فحص هالات داكنة حول النص (لن نُفقد أي شيء)
    for label, box in bx.items():
        x0, x1, y0, y1 = box
        sub = arr[y0:y1 + 1, x0:x1 + 1, :].astype(float)
        bg = prof[x0:x1 + 1, :][None, :, :]
        dark = (bg - sub).max(axis=2)
        print(f"{name}/{label}: max dark-halo = {dark.max():.0f} (يجب <= 12 ليكون التحويل آمناً)")

    # 3) أقنعة النصين
    a_brand = extract_alpha(arr, bx["brand"], prof)
    a_url   = extract_alpha(arr, bx["url"], prof)

    # 4) إعادة طلاء الشريط كاملاً بالتدرج (يمحو النصين)
    canvas = arr.copy()
    canvas[bt:bb + 1, :, :] = np.clip(prof[None, :, :], 0, 255).astype(np.uint8)

    # 5) التركيب في الموضعين المعكوسين — نفس الصفوف الرأسية حرفياً
    #    الاسم → يمين (حافة يمنى = W-MARGIN_R)  |  الرابط → يسار (حافة يسرى = MARGIN_L)
    bx0, bx1, by0, by1 = bx["brand"]
    ux0, ux1, uy0, uy1 = bx["url"]
    bw = bx1 - bx0 + 1
    uw = ux1 - ux0 + 1
    brand_new_x = W - MARGIN_R - bw + 1
    url_new_x   = MARGIN_L
    recomposite(canvas, a_brand, brand_new_x, by0)
    recomposite(canvas, a_url,   url_new_x,   uy0)

    # 6) حفظ
    out = Image.fromarray(canvas)
    p = f"{FIXED}/{name}.png"
    out.save(p, "PNG")
    sha = hashlib.sha256(open(p, "rb").read()).hexdigest()
    report[name] = {"orig_size": [W, H], "brand_new_x": brand_new_x, "url_new_x": url_new_x,
                    "sha256": sha, "bytes": os.path.getsize(p)}
    print(f"{name}: saved {p}  {report[name]['bytes']} bytes  sha256={sha[:16]}...")

json.dump(report, open(f"{FIXED}/fixed_meta.json", "w"), indent=2)
print("DONE")
