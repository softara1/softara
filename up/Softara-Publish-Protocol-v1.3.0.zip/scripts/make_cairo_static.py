#!/usr/bin/env python3
"""توليد أوزان Cairo الثابتة بشكل صحيح (inplace) + بصمات نهائية"""
import hashlib, os
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont

FDIR = "/home/z/my-project/scripts/t928_fix/fonts"
VAR = f"{FDIR}/Cairo-var.ttf"
weights = {400: "Regular", 600: "SemiBold", 700: "Bold", 800: "ExtraBold", 900: "Black"}
for w, name in weights.items():
    f = TTFont(VAR)
    instantiateVariableFont(f, {"wght": w, "slnt": 0}, inplace=True, updateFontNames=True)
    f["OS/2"].usWeightClass = w
    out = f"{FDIR}/Cairo-{name}.ttf"
    f.save(out)
    h = hashlib.sha256(open(out, "rb").read()).hexdigest()
    chk = TTFont(out)
    print(f"Cairo-{name}.ttf  {os.path.getsize(out)}B  fvar={'fvar' in chk} w={chk['OS/2'].usWeightClass}  sha256={h}")
