#!/usr/bin/env python3
"""استبدال صور موضوع منشور في موضعه + تحديث حقلي OG — نسخة حزمة (بلا أسرار)
يقرأ بيانات دخول المؤسس من بيئة المشروع (متغيرات SFORUM_USER/SFORUM_PASS أو وحدة الحسابات).
المنهجية الكاملة موثقة في docs/02 §7. الاستخدام:
  python3 replace_in_topic.py <topic_slug_or_tNNN> <post_id> old1=new1 old2=new2 ...
آخر وسيط اختياري: --og <new_cover_url> لتحديث og_img_facebook/twitter
"""
import re, sys, os, json, html as H, requests

BASE = "https://softara.yoo7.com"

def new_session():
    s = requests.Session()
    s.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                      "Accept-Language": "ar,ar-SA;q=0.9,en;q=0.8"})
    user = os.environ.get("SFORUM_USER"); pwd = os.environ.get("SFORUM_PASS")
    if not user or not pwd:
        try:
            sys.path.insert(0, "/home/z/my-project/scripts")
            from softara_accounts import ACCOUNTS
            user = ACCOUNTS["admin"]["username"]; pwd = ACCOUNTS["admin"]["password"]
        except Exception:
            raise SystemExit("بيانات دخول المؤسس غير متاحة (SFORUM_USER/SFORUM_PASS)")
    s.get(BASE + "/login", timeout=30)
    s.post(BASE + "/login", data={"username": user, "password": pwd, "autologin": "1", "login": "تسجيل الدخول"}, timeout=40)
    # تحقق دخول قوي (الكاشف الضعيف يقع إيجابياً كاذباً على سلاسل JS)
    chk = s.get(f"{BASE}/post?f=13&mode=newtopic", timeout=30)
    if not ('name="subject"' in chk.text and 'name="message"' in chk.text):
        raise SystemExit("فشل دخول المؤسس")
    return s

def main():
    args = sys.argv[1:]
    topic, pid = args[0], args[1]
    og = None
    if "--og" in args:
        i = args.index("--og"); og = args[i + 1]; args = args[:i] + args[i + 2:]
    mapping = dict(a.split("=", 1) for a in args[2:])
    s = new_session()
    r = s.get(f"{BASE}/post?p={pid}&mode=editpost", timeout=40)
    fm = re.search(r'<form[^>]*action="/post"[^>]*>(.*?)</form>', r.text, re.S)
    body = fm.group(1)
    fields = {}
    for m in re.finditer(r'<input\b[^>]*>', body):
        tag = m.group(0)
        nmm = re.search(r'name="([^"]+)"', tag)
        if not nmm: continue
        nm = nmm.group(1)
        ty = re.search(r'type="([^"]*)"', tag)
        ty = ty.group(1).lower() if ty else "text"
        vl = re.search(r'value="([^"]*)"', tag)
        val = H.unescape(vl.group(1)) if vl else ""
        if ty in ("submit", "button", "image"): continue
        if ty in ("checkbox", "radio"):
            if "checked" in tag: fields.setdefault(nm, val)
            continue
        fields[nm] = val
    for m in re.finditer(r'<textarea\b[^>]*name="([^"]+)"[^>]*>(.*?)</textarea>', body, re.S):
        fields[m.group(1)] = H.unescape(m.group(2))
    msg_old = fields["message"]
    open(f"message_backup_{pid}.bbcode", "w", encoding="utf-8").write(msg_old)
    msg_new = msg_old
    for old, new in mapping.items():
        n = msg_new.count(old)
        assert n > 0, f"الرابط غير موجود في الرسالة: {old}"
        msg_new = msg_new.replace(old, new)
    # إثبات انحصار الفرق في الروابط فقط
    so = msg_old
    for old in mapping: so = so.replace(old, "@@IMG@@")
    sn = msg_new
    for new in mapping.values(): sn = sn.replace(new, "@@IMG@@")
    assert so == sn, "الفرق ليس في الروابط فقط — إيقاف"
    if og:
        if "topic_og_img_facebook" in fields: fields["topic_og_img_facebook"] = og
        if "topic_og_img_twitter" in fields: fields["topic_og_img_twitter"] = og
    fields["message"] = msg_new
    fields["post"] = "1"
    files = {k: (None, v) for k, v in fields.items()}
    r2 = s.post(BASE + "/post", files=files, timeout=120, allow_redirects=True)
    err = re.search(r'(بيانات خاطئة|ليست لديك صلاحيات[^<]{0,60})', r2.text)
    print("POST:", r2.status_code, "| خطأ:", err.group(0) if err else "لا شيء")
    json.dump({"post_id": pid, "mapping": mapping, "og": og, "status": r2.status_code},
              open("submit_result.json", "w"), ensure_ascii=False, indent=2)

if __name__ == "__main__":
    main()
