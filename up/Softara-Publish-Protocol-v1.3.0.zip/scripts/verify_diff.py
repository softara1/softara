#!/usr/bin/env python3
"""تحقق نهائي: خارج الشريط تطابق بكسلي 100% + داخل الشريط تغيّر في منطقتي النص فقط + شرائح مقارنة"""
from PIL import Image
import numpy as np, json

OUT = "/home/z/my-project/scripts/t928_fix"
BANDS = {"cover": (706, 767), "fig1": (498, 559), "fig2": (498, 559), "fig3": (498, 559)}
BOXES = {
    "cover": {"brand": (36, 275, 724, 752), "url": (1121, 1307, 723, 750)},
    "fig1":  {"brand": (36, 275, 516, 548), "url": (977, 1163, 515, 547)},
    "fig2":  {"brand": (36, 275, 516, 548), "url": (977, 1163, 515, 547)},
    "fig3":  {"brand": (36, 275, 516, 548), "url": (977, 1163, 515, 547)},
}
MARGIN_L, MARGIN_R = 42, 43
res = {}
for name, (bt, bb) in BANDS.items():
    o = np.asarray(Image.open(f"{OUT}/orig/{name}.png").convert("RGB")).astype(int)
    f = np.asarray(Image.open(f"{OUT}/fixed/{name}.png").convert("RGB")).astype(int)
    H, W = o.shape[:2]
    d = np.abs(o - f).max(axis=2)
    outside = d.copy(); outside[bt:bb + 1, :] = 0
    outside_max = int(outside.max())
    inside = d[bt:bb + 1, :]
    changed_cols = np.where(inside.max(axis=0) > 2)[0]
    # النطاقات الجديدة المتوقعة
    bx0, bx1 = BOXES[name]["brand"][0], BOXES[name]["brand"][1]
    ux0, ux1 = BOXES[name]["url"][0], BOXES[name]["url"][1]
    bw, uw = bx1 - bx0 + 1, ux1 - ux0 + 1
    exp_new_brand = (W - MARGIN_R - bw + 1, W - MARGIN_R)
    exp_new_url = (MARGIN_L, MARGIN_L + uw - 1)
    ok_cols = (changed_cols.min() >= min(exp_new_brand[0], exp_new_url[0]) - 2 and
               changed_cols.max() <= max(exp_new_brand[1], exp_new_url[1]) + 2)
    # أقصى فرع داخل مناطق النص الجديدة (يجب <= 6 بسبب إعادة المزج)
    b_new = inside[:, exp_new_brand[0]:exp_new_brand[1] + 1].max()
    u_new = inside[:, exp_new_url[0]:exp_new_url[1] + 1].max()
    res[name] = {
        "outside_band_max_diff": outside_max,
        "changed_cols_range": [int(changed_cols.min()), int(changed_cols.max())] if len(changed_cols) else None,
        "expected_new_regions": {"brand_right": exp_new_brand, "url_left": exp_new_url},
        "columns_confined_to_new_regions": bool(ok_cols),
        "max_diff_in_new_regions": int(max(b_new, u_new)),
    }
    print(name, json.dumps(res[name]))
    # شرائح مقارنة قبل/بعد (للتقرير)
    h_band = bb - bt + 1
    cmp_img = Image.new("RGB", (W, h_band * 2 + 8), (20, 20, 30))
    cmp_img.paste(Image.open(f"{OUT}/orig/{name}.png").convert("RGB").crop((0, bt, W, bb + 1)), (0, 0))
    cmp_img.paste(Image.open(f"{OUT}/fixed/{name}.png").convert("RGB").crop((0, bt, W, bb + 1)), (0, h_band + 8))
    cmp_img.save(f"{OUT}/qa/{name}_before_after.png")

json.dump(res, open(f"{OUT}/qa/diff_report.json", "w"), indent=2)
print("SUMMARY:", all(v["outside_band_max_diff"] == 0 and v["columns_confined_to_new_regions"] for v in res.values()))
