#!/usr/bin/env python3
"""رفع الصور إلى Servimg + تحقق SHA-256 بايتي — نسخة حزمة (بلا أسرار)
الأسرار: بيانات حساب Servimg للمنتدى تُقرأ من بيئة المشروع (متغيرات SERV_EMAIL/SERV_PASS
أو وحدة servimg_fa الداخلية للبيئة). لا تُكتب في أي حزمة أو مستودع.
الاستخدام: python3 upload_servimg_verify.py file1.png [file2.png ...]
"""
import sys, os, json, hashlib, requests

def upload_bytes(img_bytes, fname, ctype="image/png"):
    """يستخدم جلسة Servimg من بيئة المشروع — الوصفة الموثقة في docs/02 §6"""
    try:
        sys.path.insert(0, "/home/z/my-project/scripts")
        from servimg_fa import upload_bytes as _up
        return _up(img_bytes, fname, ctype)
    except FileNotFoundError:
        raise SystemExit("بيئة المشروع غير متوفرة — جهّز جلسة Servimg وفق docs/02 §6")

def main():
    out = {}
    for p in sys.argv[1:]:
        raw = open(p, "rb").read()
        local_sha = hashlib.sha256(raw).hexdigest()
        url, th, info = upload_bytes(raw, os.path.basename(p), "image/png")
        entry = {"local_sha256": local_sha, "local_bytes": len(raw), "servimg_url": url, "info": info}
        if url:
            r = requests.get(url, timeout=60, headers={"User-Agent": "Mozilla/5.0"})
            remote_sha = hashlib.sha256(r.content).hexdigest()
            entry.update({"remote_bytes": len(r.content), "remote_sha256": remote_sha,
                          "bytes_identical": remote_sha == local_sha})
        out[os.path.basename(p)] = entry
        print(p, "->", url or "FAIL", "| identical:", entry.get("bytes_identical"))
    json.dump(out, open("servimg_upload.json", "w"), indent=2, ensure_ascii=False)

if __name__ == "__main__":
    main()
