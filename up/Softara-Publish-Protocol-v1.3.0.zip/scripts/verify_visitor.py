#!/usr/bin/env python3
"""فحص زائر حي لموضوع منشور: صور + فيض أفقي + SEO/OG — حاسب 1366 + هاتف 390
الاستخدام: python3 verify_visitor.py <canonical_topic_url>
المخرجات: لقطات PNG + تقرير JSON في المجلد الحالي
"""
import re, sys, json, hashlib, requests
from playwright.sync_api import sync_playwright

TOPIC = sys.argv[1] if len(sys.argv) > 1 else "https://softara.yoo7.com/t928-topic"
OUT = "."

def check_http_images(html):
    urls = sorted(set(re.findall(r'https://i\.servimg\.com/[^\s"\'<>]+', html)))
    res = {}
    for u in urls:
        try:
            r = requests.get(u, timeout=40, headers={"User-Agent": "Mozilla/5.0"})
            res[u] = {"status": r.status_code, "sha256": hashlib.sha256(r.content).hexdigest()[:16] if r.status_code == 200 else None}
        except Exception as e:
            res[u] = {"err": str(e)[:60]}
    return res

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    report = {"topic": TOPIC}
    for label, vw, vh, mobile in [("desktop", 1366, 900, False), ("mobile", 390, 844, True)]:
        ctx = b.new_context(viewport={"width": vw, "height": vh}, is_mobile=mobile, locale="ar")
        pg = ctx.new_page()
        pg.goto(TOPIC, wait_until="networkidle", timeout=90000)
        pg.wait_for_timeout(2500)
        info = pg.evaluate("""() => ({
            title: document.title,
            overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
            imgs: Array.from(document.images).filter(i => i.src.includes('servimg'))
                  .map(i => ({f: i.src.split('/').pop(), ok: i.complete && i.naturalWidth > 0}))
        })""")
        pg.screenshot(path=f"{OUT}/visitor_{label}_full.png", full_page=True)
        report[label] = info
        ctx.close()
    b.close()

h = requests.get(TOPIC, timeout=40, headers={"User-Agent": "Mozilla/5.0"}).text
report["seo"] = {
    "title": re.search(r"<title>(.*?)</title>", h, re.S).group(1).strip(),
    "meta_description": (re.search(r'<meta name="description" content="([^"]*)"', h) or [None, None])[1],
    "og_image": (re.search(r'<meta property="og:image" content="([^"]*)"', h) or [None, None])[1],
    "og_title": (re.search(r'<meta property="og:title" content="([^"]*)"', h) or [None, None])[1],
    "twitter_image": (re.search(r'<meta name="twitter:image" content="([^"]*)"', h) or [None, None])[1],
}
report["servimg_http"] = check_http_images(h)
json.dump(report, open(f"{OUT}/visitor_report.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(json.dumps(report, ensure_ascii=False, indent=1)[:2500])
