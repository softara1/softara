<!DOCTYPE HTML>
<html lang="{L_LANG_HTML}" dir="rtl">
<head>
    <meta charset="{S_CONTENT_ENCODING}" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="google-site-verification" content="A6WEcyMAUSKHyOebah-UiICKjsZj4mCOUh3EevyKrqQ" />
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-T33K4JC5');</script>
<!-- End Google Tag Manager -->
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet"/>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
  <!-- softara-fonts-v1: تطبيق مبكر للخط المحفوظ قبل الرسم (بلا وميض) — الخريطة مرجع مطابق لكود softara-fonts-v1 -->
  <script>/* softara-fonts-v1 bootstrap */
  (function(){var F={default:{stack:"'Tajawal',sans-serif",css:""},cairo:{stack:"'Cairo','Tajawal',sans-serif",css:"https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap"},tajawal:{stack:"'Tajawal',sans-serif",css:""},almarai:{stack:"'Almarai','Tajawal',sans-serif",css:"https://fonts.googleapis.com/css2?family=Almarai:wght@400;700;800&display=swap"},ibmplex:{stack:"'IBM Plex Sans Arabic','Tajawal',sans-serif",css:"https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap"},notokufi:{stack:"'Noto Kufi Arabic','Tajawal',sans-serif",css:"https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600;700;800&display=swap"},reemkufi:{stack:"'Reem Kufi','Tajawal',sans-serif",css:"https://fonts.googleapis.com/css2?family=Reem+Kufi:wght@400;600;700&display=swap"},amiri:{stack:"'Amiri','Tajawal',serif",css:"https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&display=swap"}};window.SA_FONTS=F;try{var k=localStorage.getItem("f_font");if(k&&F[k]&&F[k].stack){document.documentElement.style.setProperty("--sa-font",F[k].stack);if(F[k].css){var l=document.createElement("link");l.id="saFontCss";l.rel="stylesheet";l.href=F[k].css;document.head.appendChild(l);}}}catch(e){ }})();
  </script>
  <style>/* softara-fonts-v1: قسم نوع الخط + التغطية الموحدة للخط */
  :root{--sa-font:'Tajawal',sans-serif}
  html body,html #fa_toolbar,html #profile-notifications,html .cyb-stats-wrapper,html .user-hover-card,html .flx-topic-container,html .flx-stat-pill strong,html .fa_like_others .fa_like_tooltip,html #customNotifBadge,html #a7la-PAGINATION *,html #a7la-PAGINATION-B *,html .sa-awards-btn{font-family:var(--sa-font)!important}
  html button,html input:not([type=checkbox]):not([type=radio]):not([type=file]):not([type=range]):not([type=color]),html select,html optgroup{font-family:var(--sa-font)!important}
  /* كتل الأكواد والأيقونات والمحرر خارج التغطية عمدًا (خطوط خاصة) */
  #saFontSection .sa-font-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  /* قائمة الخطوط المنسدلة (تحسين 2026-10-10): مطوية افتراضيًا بوجود JS (فئة sa-font-js
     يضيفها كود softara-fonts-v1) — وبلا JS تبقى ظاهرة كالسابق فلا حبس للوظيفة */
  #saFontSection.sa-font-js .sa-font-head{cursor:pointer;user-select:none;-webkit-user-select:none;transition:color .18s ease}
  #saFontSection.sa-font-js .sa-font-head:hover{color:var(--primary-color,#8b5cf6)}
  #saFontSection.sa-font-js .sa-font-head .sa-font-chev{margin-inline-start:6px;font-size:.72em;opacity:.65;transition:transform .22s ease}
  #saFontSection.sa-font-js.sa-font-open .sa-font-head .sa-font-chev{transform:rotate(180deg)}
  #saFontSection.sa-font-js #saFontOptions{display:none}
  #saFontSection.sa-font-js.sa-font-open #saFontOptions{display:grid;animation:saFontSlideIn .2s ease}
  @keyframes saFontSlideIn{from{opacity:0;transform:translateY(-5px)}to{opacity:1;transform:translateY(0)}}
  @media(prefers-reduced-motion:reduce){#saFontSection.sa-font-js.sa-font-open #saFontOptions{animation:none}}
  .sa-font-btn{display:flex;flex-direction:column;align-items:flex-start;gap:2px;padding:9px 11px;line-height:1.35;min-width:0}
  .sa-font-btn .sa-f-name{font-size:.86rem;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
  .sa-font-btn .sa-f-prev{font-size:.74rem;opacity:.62;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
  @media(max-width:430px){#saFontSection .sa-font-grid{grid-template-columns:1fr 1fr;gap:6px}.sa-font-btn{padding:8px 9px}}
  </style>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>



    <!-- BEGIN switch_canonical_url -->
    <link rel="canonical" href="{switch_canonical_url.CANONICAL_URL}" />
    <!-- END switch_canonical_url -->

    {META_FAVICO}
    {META}
    {META_FB_LIKE}

    <!-- softara-seo (المرحلة 1): نُقل من كود seo-core-v1 إلى القالب — og:locale (المنصة لا تصدره) + أنماط روابط الفوتر -->
    <meta property="og:locale" content="ar_AR" />
    <style id="sa-foot-links-style">#sa-foot-links{display:block;text-align:center;padding:10px 0 18px;font-size:12.5px;opacity:.75}#sa-foot-links a{color:inherit;text-decoration:none}#sa-foot-links a:hover{color:var(--primary-color,#8b5cf6);text-decoration:underline}</style>

    <title>{SITENAME_TITLE}{PAGE_TITLE}</title>

    {T_HEAD_STYLESHEET}
    {CSS}

    <meta name="theme-color" content="{GG_THEME_COLOR}" />

    <link rel="search" type="application/opensearchdescription+xml" href="/improvedsearch.xml" title="{SITENAME}" />
    <link rel="search" type="application/opensearchdescription+xml" href="{URL_BOARD_DIRECTORY}/search/improvedsearch.xml" title="{SEARCH_FORUMS}" />

    <script src="{JQUERY_PATH}" type="text/javascript"></script>
    <!-- BEGIN switch_recent_jquery -->
    <script src="{JS_DIR}jquery1.9/jquery-migrate-1.4.1.js" type="text/javascript"></script>
    <script src="{JQUERY_DIR}browser/v1.0/jquery.browser.min.js" type="text/javascript"></script>
    <script src="{JQUERY_DIR}support/jquery.support.js" type="text/javascript"></script>
    <!-- END switch_recent_jquery -->

    <script src="{JS_DIR}{L_LANG}.js" type="text/javascript"></script>

    <!-- BEGIN switch_fb_login -->
    <script src="{switch_fb_login.JS_FB_LOGIN}" type="text/javascript"></script>
    <!-- END switch_fb_login -->

    <!-- BEGIN switch_ticker -->
    <link type="text/css" rel="stylesheet" href="{JS_DIR}jquery/ticker/ticker.css" />
    <script src="{JS_DIR}jquery/ticker/ticker.js" type="text/javascript"></script>
    <!-- END switch_ticker -->

    <!-- BEGIN switch_ticker -->
    <script type="text/javascript">
        //<![CDATA[
        $(document).ready(function () {
            Ticker.start({
                height : {switch_ticker.HEIGHT},
                spacing : {switch_ticker.SPACING},
                speed : {switch_ticker.SPEED},
                direction : '{switch_ticker.DIRECTION}',
                pause : {switch_ticker.STOP_TIME},
                max_height: {switch_ticker.HEIGHT},
            });
        });
        //]]>
    </script>
    <!-- END switch_ticker -->
    <script type="text/javascript">
        //<![CDATA[

        //]]>
    </script>
    <script type="text/javascript">
        $(document).scroll(function() {
            var y = $(this).scrollTop();
            if (y > 164) {
                if($('.btn-fixed').find('.btn-fixed-txt').length !== 0){
                    $('.btn-fixed').addClass('btn-scrolled');
                }
            } else {
                if($('.btn-fixed').find('.btn-fixed-txt').length !== 0) {
                    $('.btn-fixed').removeClass('btn-scrolled');
                }
            }
        });
    </script>
    <!-- BEGIN switch_report_popup -->
    <script type="text/javascript">
        //<![CDATA[
        $(document).ready(function () {
            report = window.open('{switch_report_popup.U_REPORT_POPUP}', '_phpbbreport', 'HEIGHT={switch_report_popup.S_HEIGHT},resizable=yes,scrollbars=no,WIDTH={switch_report_popup.S_WIDTH}');
            if (report != null) {
                report.focus();
            }
        });//]]>
    </script>
    <!-- END switch_report_popup -->
    <!-- BEGIN switch_enable_pm_popup -->
    <script type="text/javascript">
        //<![CDATA[
        $(document).ready(function () {
            pm = window.open('{U_PRIVATEMSGS_POPUP}', '_faprivmsg', 'HEIGHT=225,resizable=yes,WIDTH=400');
            if (pm != null) {
                pm.focus();
            }
        });
        //]]>
    </script>
    <!-- END switch_enable_pm_popup -->
    <!-- BEGIN switch_login_popup -->
    <script type="text/javascript">
        //<![CDATA[
    var logInPopUpLeft, logInPopUpTop, logInPopUpWidth = {LOGIN_POPUP_WIDTH},
    logInPopUpHeight = {LOGIN_POPUP_HEIGHT}, logInBackgroundResize = true, logInBackgroundClass = false;

    $(document).ready(function () {
        $(window).resize(function () {
            var windowWidth = document.documentElement.clientWidth;
            var popupWidth = $("#login_popup").width();
            var mypopup = $("#login_popup");

            $("#login_popup").css({
                "left": windowWidth / 2 - popupWidth / 2
            });
        });
    });
        //]]>
    </script>
    <!-- END switch_login_popup -->

    {RICH_SNIPPET_GOOGLE}

    <!-- Fancybox v4 : يجب تحميله قبل سكربتات المنصة والقالب -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.css" />
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>

    {HOSTING_JS}


    <!-- softara (المرحلة 4/task37): كتلة GA الرسمية كانت تجعل المنصة تصدر مقتطفين مكررين لنفس المعرف — استُبدلت بمقتطف واحد مباشر. تنبيه: إن غيّر المالك معرف GA4 من اللوحة (part=general&sub=stats&mode=g_analytics) فيجب تحديث المعرف هنا يدوياً -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-8S6Q46QJS5"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-8S6Q46QJS5', {'anonymize_ip': true, 'store_gac': false, 'cookie_expires': 13 * 30 * 24 * 60 * 60});
    </script>



<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
<link rel="preconnect" href="https://softara-cdn.almoatn1.workers.dev" crossorigin>
<link href="https://softara-cdn.almoatn1.workers.dev/up/softara-theme-merged-v2.css" rel="stylesheet" />
    <!-- softara (المرحلة 4/task37): style.css + styles.css دُمجا حرفياً في ملف واحد (تحقق CSSOM مرتب كامل في المتصفح — نفس السلوك بطلب واحد) -->
<link href="https://softara-cdn.almoatn1.workers.dev/up/profileaddbody.css" rel="stylesheet" />
<link href="https://softara-cdn.almoatn1.workers.dev/up/postingbody.css" rel="stylesheet" />
<link href="https://softara-cdn.almoatn1.workers.dev/up/mergebody.css" rel="stylesheet" />
    <!-- softara-article-styling v1.1.0 — نظام تنسيق مقالات سوفتارا (خلفيات العناوين المتدرجة) -->
    <link href="https://cdn.jsdelivr.net/gh/softara1/softara@main/up/softara-article-styling-v1.1.1.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/gh/softara1/softara@ec48fc7f/up/a7la-7ekaya.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/gh/softara1/softara@ec48fc7f/up/a7la-Sections.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/gh/softara1/softara@ec48fc7f/up/a7la-Topics.js" type="text/javascript"></script>
<script>/* softara-audit1004 (batch1): بوابة إشعارات الزوار — منع 403 وجلب دوري بلا فائدة للزائر */
(function(){var raw=null;try{Object.defineProperty(window,"flxRefreshNotifications",{configurable:true,
get:function(){var g=window._userdata;return (!g||parseInt(g.session_logged_in,10)!==1)?function(){/*g*/}:(raw||function(){/*g*/})},
set:function(v){raw=v}})}catch(e){/*g*/}})();</script>
<script src="https://cdn.jsdelivr.net/gh/softara1/softara@ec48fc7f/up/a7la2026.js" type="text/javascript"></script>
<script type="text/javascript">
    //<![CDATA[
    /* ===== قائمة الموقع (موبايل): فتح/إغلاق القائمة الرئيسية والقوائم المنسدلة ===== */
    function toggleMainMenu() {
        var menu = document.getElementById('mainMenu');
        if (menu) { menu.classList.toggle('active'); }
        var btn = document.getElementById('menuToggleBtn');
        if (btn) { btn.setAttribute('aria-expanded', menu && menu.classList.contains('active') ? 'true' : 'false'); }
    }
    document.querySelectorAll('.has-dropdown > a, .has-dropdown > span').forEach(function (link) {
        link.addEventListener('click', function (e) {
            if (window.innerWidth <= 992) {
                e.preventDefault();
                this.parentElement.classList.toggle('mobile-open');
            }
        });
    });
    /* ===== تصحيح الجمع العربي في العبارات الرقمية الثابتة بالتصميم =====
       ينطبق على: المساهمات/مشاهدة/موضوع/مواضيع/رد/ردود/صوت
       القاعدة: 1 مفرد - 2 مثنى - 3..10 جمع - 11 فأكثر مفرد */
    (function () {
        var WORDS = [
            ['المساهمات', ['مساهمة', 'مساهمتان', 'مساهمات', 'مساهمة']],
            ['مشاهدة',    ['مشاهدة', 'مشاهدتان', 'مشاهدات', 'مشاهدة']],
            ['مواضيع',    ['موضوع', 'موضوعان', 'مواضيع', 'موضوع']],
            ['موضوع',     ['موضوع', 'موضوعان', 'مواضيع', 'موضوع']],
            ['ردود',      ['رد', 'ردان', 'ردود', 'رد']],
            ['رد',        ['رد', 'ردان', 'ردود', 'رد']],
            ['صوت',       ['صوت', 'صوتان', 'أصوات', 'صوت']]
        ];
        function toNum(s) {
            for (var i = 0; i < 10; i++) { s = s.split(String.fromCharCode(1632 + i)).join(String(i)); }
            return parseInt(s, 10);
        }
        function pick(n) {
            if (n === 1) return 0;
            if (n === 2) return 1;
            if (n >= 3 && n <= 10) return 2;
            return 3;
        }
        function fixNode(el) {
            var html = el.innerHTML, out = html;
            WORDS.forEach(function (w) {
                var forms = w[1];
                var re = new RegExp('([0-9\u0660-\u0669]+)[\\s\u00A0]*' + w[0] + '(?![\u0600-\u06FF])', 'g');
                out = out.replace(re, function (mm, num) {
                    var n = toNum(num);
                    return isNaN(n) ? mm : num + ' ' + forms[pick(n)];
                });
            });
            if (out !== html) { el.innerHTML = out; }
        }
        function run() {
            var nodes = document.querySelectorAll('.board-stats, .modern-stats, .topic-meta-info, .modern-topic-stats, .poll-num, .topic-meta, .adv-card');
            for (var i = 0; i < nodes.length; i++) { fixNode(nodes[i]); }
        }
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', run);
        } else {
            run();
        }
    })();
    //]]>
</script>

  <style>
/* زر القائمة (هامبرغر) - يظهر على الموبايل فقط */
.hamburger-menu-btn { display: none; }
@media (max-width: 992px) {
    .hamburger-menu-btn {
        display: inline-flex !important;
        align-items: center;
        justify-content: center;
    }
}
/* عنوان الترحيب: h2 بدل h1 حتى لا يتكرر h1 مع عنوان الصفحة */
.main-header h2.main-header-title { font-size: 3rem; margin-bottom: 10px; }

/* ===== توحيد محاذاة روابط القائمة العلوية =====
   التصميم يعتمد row-reverse لعرض RTL؛ نوحّد فقط عرض الأيقونات
   والمسافات حتى تظهر كل الروابط (القديمة والجديدة) بنفس التنسيق */
.main-menu > li > a i:not(.arrow-icon),
.sub-menu li a i {
    width: 18px;
    text-align: center;
    flex-shrink: 0;
}
.main-menu > li > a,
.sub-menu li a {
    white-space: nowrap;
}
.main-menu > li > a i.arrow-icon { width: auto; }

/* ===== مشغل القرآن الكريم - سوفتارا ===== */
.quran-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(15,23,42,.75); backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px); z-index: 100000; display: none; justify-content: center; align-items: center; }
.quran-overlay.active { display: flex; }
.quran-box { background: var(--card-bg, #fff); color: var(--text-color, #1f2937); width: 92%; max-width: 520px; border-radius: 18px; padding: 1.6rem; box-shadow: 0 20px 45px rgba(0,0,0,.35); position: relative; max-height: 90vh; overflow-y: auto; direction: rtl; text-align: right; -webkit-overflow-scrolling: touch; }
.quran-box h3 { margin: 0 0 4px 0; color: var(--primary-color, #8b5cf6); display: flex; align-items: center; gap: 8px; font-size: 1.25rem; }
.quran-box .quran-sub { color: var(--text-muted, #6b7280); font-size: .85rem; margin-bottom: 1rem; }
.quran-close { position: absolute; top: 14px; left: 14px; background: none; border: none; font-size: 1.3rem; color: var(--text-muted, #94a3b8); cursor: pointer; -webkit-appearance: none; appearance: none; padding: 4px; }
.quran-close:hover { color: #ef4444; }

/* ===== صناديق select — إصلاحات شاملة لكل المتصفحات ===== */
.quran-field { margin-bottom: 12px; position: relative; }
/* تجاوز max-width:300px من styles.css العام على .select wrapper */
.quran-field .select {
    position: relative;
    width: 100% !important;
    max-width: 100% !important;
    display: block;
}
.quran-field label {
    display: flex; align-items: center; gap: 6px;
    font-weight: 700; font-size: .9rem; margin-bottom: 5px;
    text-align: right; color: var(--text-color, #1f2937);
}
.quran-field label i { color: var(--primary-color, #8b5cf6); }
.quran-field select {
    width: 100% !important;
    max-width: 100% !important;  /* تجاوز max-width:300px من styles.css العام */
    /* padding: top right bottom left — في RTL: left=36px لمكان السهم، right=14px للمساحة العادية */
    padding: 11px 14px 11px 36px;
    border: 2px solid var(--border-color, #e5e7eb);
    border-radius: 10px;
    background: var(--card-bg, #ffffff);
    color: var(--text-color, #1f2937);
    font-family: inherit; font-size: .95rem; font-weight: 600;
    direction: rtl; text-align: right;
    cursor: pointer;
    transition: border-color 0.2s, box-shadow 0.2s;
    min-height: 44px;
    /* إزالة السهم الافتراضي في كل المتصفحات */
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    /* Firefox */
    -moz-appearance: textfield;
    /* IE10+ */
    -ms-appearance: none;
}
/* إعادة appearance لـ Firefox لأنه يحتاج قيمة خاصة */
.quran-field select {
    -webkit-appearance: none;
    -moz-appearance: none;
}
/* السهم المخصص — يظهر في كل المتصفحات */
.quran-field::after {
    content: "\25BC";
    position: absolute;
    top: 50%;
    left: 14px;
    transform: translateY(-50%);
    pointer-events: none;
    color: var(--primary-color, #8b5cf6);
    font-size: .7rem;
    z-index: 1;
    line-height: 1;
}
/* نُزيل السهم المخصص في Firefox القديم ونستخدم background-image */
@-moz-document url-prefix() {
    .quran-field::after { display: none; }
    .quran-field select {
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='%238b5cf6' d='M0 0l5 6 5-6z'></path></svg>");
        background-repeat: no-repeat;
        background-position: left 14px center;
        padding-left: 36px;
    }
}
.quran-field select:hover { border-color: var(--primary-color, #8b5cf6); }
.quran-field select:focus {
    outline: none;
    border-color: var(--primary-color, #8b5cf6);
    box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.12);
}
.quran-field select option {
    padding: 8px 12px;
    background: var(--card-bg, #ffffff);
    color: var(--text-color, #1f2937);
    font-weight: 500;
    font-family: inherit;
}
.quran-field select option:checked,
.quran-field select option:selected {
    background: var(--primary-color, #8b5cf6);
    color: #ffffff;
    font-weight: 700;
}

.quran-now {
    text-align: center; font-weight: 800; margin: 12px 0 8px;
    min-height: 28px; color: var(--primary-color, #8b5cf6);
    font-size: 1rem; padding: 8px 12px;
    background: rgba(139, 92, 246, 0.06);
    border-radius: 8px;
    border: 1px dashed rgba(139, 92, 246, 0.25);
    word-break: break-word;
    line-height: 1.5;
    display: flex; align-items: center; justify-content: center;
    flex-wrap: wrap; gap: 6px;
}
.quran-now button {
    background: var(--primary-color, #8b5cf6) !important;
    color: #fff !important;
    border: none;
    padding: 6px 16px;
    border-radius: 6px;
    cursor: pointer;
    font-family: inherit;
    font-size: .85rem;
    font-weight: 600;
    margin-right: 4px;
}
.quran-now button:hover { filter: brightness(1.1); }

.quran-audio-wrap { direction: ltr; margin-bottom: 8px; }
.quran-audio-wrap audio {
    width: 100%;
    max-height: 38px;
    border-radius: 8px;
}

/* ===== أزرار التنقل + زر الراديو ===== */
.quran-nav-btns { display: flex; justify-content: center; gap: 8px; flex-wrap: wrap; }
.quran-nav-btns button {
    background: var(--primary-color, #8b5cf6);
    color: #fff;
    border: none;
    padding: 9px 16px;
    border-radius: 10px;
    font-family: inherit;
    font-weight: 700;
    cursor: pointer;
    display: inline-flex; align-items: center; gap: 6px;
    transition: opacity .2s, transform .15s;
    font-size: .85rem;
    -webkit-appearance: none; appearance: none;
}
.quran-nav-btns button:hover { opacity: .88; transform: translateY(-1px); }
.quran-nav-btns button:active { transform: translateY(0); }
.quran-nav-btns button.q-secondary {
    background: var(--bg-color, #f4f6f9);
    color: var(--text-color, #1f2937);
    border: 1px solid var(--border-color, #e5e7eb);
}
/* زر الراديو — لون مميز */
#quranRadioBtn {
    background: linear-gradient(135deg, #ef4444, #dc2626) !important;
}
#quranRadioBtn:hover { opacity: .9; }
#quranRadioBtn.radio-playing {
    background: linear-gradient(135deg, #10b981, #059669) !important;
    animation: radioPulse 1.5s ease-in-out infinite;
}
@keyframes radioPulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, .4); }
    50% { box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); }
}
.quran-hint {
    font-size: .78rem;
    color: var(--text-muted, #6b7280);
    text-align: center;
    margin-top: 10px;
    word-break: break-word;
    line-height: 1.5;
}

/* ===== توقيع المصمم أسفل النافذة ===== */
.quran-designer-credit {
    margin-top: 14px;
    padding-top: 12px;
    border-top: 1px solid var(--border-color, #e5e7eb);
    text-align: center;
    font-size: .82rem;
    line-height: 1.6;
}
.quran-designer-credit .designer-name {
    color: var(--primary-color, #8b5cf6);
    font-weight: 700;
    text-decoration: none;
    transition: color .2s;
    display: inline-block;
}
.quran-designer-credit .designer-name:hover {
    color: #7c3aed;
    text-decoration: underline;
}
.quran-designer-credit .sadaqa-jaria {
    color: var(--text-muted, #6b7280);
    font-size: .78rem;
    margin-top: 4px;
}

/* ===== استجابة الشاشات الصغيرة ===== */
@media (max-width: 480px) {
    .quran-box {
        width: 96%;
        padding: 1.2rem;
        border-radius: 14px;
    }
    .quran-box h3 { font-size: 1.05rem; }
    .quran-box .quran-sub { font-size: .8rem; }
    .quran-field label { font-size: .85rem; }
    .quran-field select {
        /* نفس التصحيح: left=32px للسهم، right=12px */
        padding: 10px 12px 10px 32px;
        font-size: .9rem;
        min-height: 40px;
    }
    .quran-now { font-size: .9rem; padding: 6px 10px; }
    .quran-nav-btns button {
        padding: 8px 12px;
        font-size: .8rem;
        flex: 1 1 auto;
        min-width: 90px;
        justify-content: center;
    }
    .quran-nav-btns { gap: 6px; }
}
@media (max-width: 360px) {
    .quran-nav-btns { flex-direction: column; }
    .quran-nav-btns button { width: 100%; }
}

@media (max-width: 992px) {
    .navbar {
        height: auto !important;
        padding: 10px 0 !important;
    }
    .nav-content {
        display: flex !important;
        justify-content: space-between !important;
        align-items: center !important;
        flex-wrap: wrap !important;
        position: relative !important;
    }
    .logo {
        width: auto !important;
        margin-bottom: 0 !important;
    }
    .nav-icons {
        display: flex !important;
        align-items: center !important;
    }
    

    .main-menu {
        display: none !important; 
        flex-direction: column !important;
        width: 100% !important;
        background: #ffffff !important;
        position: absolute !important;
        top: 100% !important;
        left: 0 !important;
        right: 0 !important;
        z-index: 999999 !important;
        box-shadow: 0 15px 25px rgba(0,0,0,0.1) !important;
        margin: 0 !important;
        padding: 0 !important;
        border-top: 3px solid var(--primary-color, #8b5cf6) !important;
        border-radius: 0 0 15px 15px !important;
    }
    .main-menu.active {
        display: flex !important;
    }
    .main-menu li {
        width: 100% !important;
        margin: 0 !important;
    }
    .main-menu li a {
        display: block !important;
        padding: 15px 20px !important;
        border-bottom: 1px solid #f0f0f0 !important;
        color: #333 !important;
        font-size: 15px !important;
        text-align: right !important;
    }

    .main-menu .has-dropdown .sub-menu {
        display: none !important;
        background: #f9f9f9 !important;
        position: static !important;
        box-shadow: none !important;
        padding: 0 15px !important;
    }
    .main-menu .has-dropdown.mobile-open .sub-menu {
        display: block !important;
    }
}

@media (max-width: 768px) {
    .cyb-list li {
        display: flex !important;
        flex-direction: column !important;
        align-items: flex-start !important;
        height: auto !important;
        padding: 15px 10px !important;
    }
    .cyb-list .topic-flex {
        width: 100% !important;
        margin-bottom: 10px !important;
    }
    .cyb-list .topic-flex a {
        white-space: normal !important; 
        display: inline-block !important;
        line-height: 1.6 !important;
        font-size: 13.5px !important;
    }
    .cyb-list .topic-meta {
        display: flex !important;
        width: 100% !important;
        justify-content: space-between !important;
        flex-direction: row !important;
        border-top: 1px dashed #ddd !important;
        padding-top: 10px !important;
        opacity: 1 !important;
        visibility: visible !important;
    }
}


@media (max-width: 768px) {
    .adv-stats-cards {
        display: grid !important;
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 12px !important;
        padding: 15px 10px !important;
    }
    .adv-card {
        padding: 15px 10px !important;
    }
    .adv-card i {
        font-size: 24px !important;
        margin-bottom: 10px !important;
    }
    .adv-card span {
        font-size: 12px !important;
    }
    .adv-card strong strong, 
    .adv-NEWEST-USER strong, 
    .adv-DESCRIPTION {
        font-size: 15px !important;
    }
}
    </style>

</head>

<body id="top">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T33K4JC5"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  
  <!-- BEGIN switch_user_logged_out -->
<style>
</style>


<div class="auth-overlay" id="authModal">
    <div class="auth-box" id="authBoxContainer">
        <button class="close-auth" onclick="closeAuthModal()" style="position:absolute; top:15px; left:15px; background:none; border:none; font-size:1.5rem; color:#94a3b8; cursor:pointer;"><i class="fas fa-times"></i></button>
        
        <div class="auth-tabs">
            <div class="auth-tab active" id="tab-login" onclick="switchAuthTab('login')"><i class="fas fa-sign-in-alt"></i> تسجيل الدخول</div>
            <div class="auth-tab" id="tab-register" onclick="switchAuthTab('register')"><i class="fas fa-user-plus"></i> حساب جديد</div>
        </div>


        <div id="form-login" class="auth-form-container active">
            <form class="auth-form" action="/login" method="post" name="form_login">
                <div class="input-group">
                    <label>اسم المستخدم أو البريد</label>
                    <input type="text" name="username" required placeholder="أدخل بياناتك هنا" />
                </div>
                
                <div class="input-group">
                    <label>كلمة المرور</label>

                    <input type="password" name="password" id="login_pass" required placeholder="••••••••" />
                </div>

                <div class="form-options" style="display:flex; justify-content:space-between; margin-bottom:20px; font-size:0.9rem;">
                    <label style="cursor:pointer; color:#64748b;"><input type="checkbox" name="autologin" checked="checked" style="accent-color:#6366f1;" /> تذكرني</label>
                    <a href="/profile?mode=sendpassword" class="forgot-pass" style="color:#6366f1; text-decoration:none;">نسيت كلمة المرور؟</a>
                </div>
                <input type="hidden" name="redirect" value="/" />
                <button type="submit" name="login" class="submit-auth-btn">دخول الآن</button>
            </form>
        </div>

       
        <div id="form-register" class="auth-form-container">
            <form class="auth-form" action="/register?step=2&agreement=1&privacy=1" method="post" name="post" id="ucp">
                
                <p style="text-align: center; color: #ef4444; font-size: 0.85rem; margin-top:-10px; margin-bottom: 20px;">جميع الحقول أدناه إجبارية لإتمام التسجيل</p>

                <div class="register-grid">

                    <div class="reg-column">
                        <div class="reg-section-title"><i class="fas fa-id-card"></i> بيانات الحساب</div>
                        
                        <div class="input-group">
                            <label>اسم العضو المستعار</label>
                            <input type="text" name="username" required placeholder="اكتب الاسم المستعار هنا" maxlength="25" />
                        </div>
                        
                        <div class="input-group">
                            <label>البريد الالكتروني</label>
                            <input type="email" name="email" required placeholder="example@gmail.com" maxlength="64" />
                        </div>
                        
                        <div class="input-group">
                            <label>كلمة السر</label>

                            <input type="password" name="password" id="reg_pass" required placeholder="••••••••" maxlength="64" autocomplete="new-password" />
                        </div>
                    </div>


                    <div class="reg-column">
                        <div class="reg-section-title"><i class="fas fa-user-circle"></i> البيانات الشخصية</div>
                        
                        <div class="input-group">
                            <label>الدولة</label>
                            <select name="profile_field_7_2" required>
                              <option value="" selected="selected">إختر أحد الإقتراحات</option>
                                <option value="0">مصر</option><option value="1">فلسطين</option><option value="2">سوريا</option><option value="3">اليمن</option><option value="4">السعودية</option><option value="5">ليبيا</option><option value="6">تونس</option><option value="7">الأردن</option><option value="8">المغرب</option><option value="9">الجزائر</option><option value="10">قطر</option><option value="11">الكويت</option><option value="12">الإمارات</option><option value="13">لبنان</option><option value="14">العراق</option><option value="15">السودان</option><option value="16">البحرين</option><option value="17">عمان</option><option value="18">الصومال</option><option value="19">موريتانيا</option><option value="20">جيبوتي</option><option value="21">جزر القمر</option><option value="22">تركيا</option><option value="23">أمريكا</option><option value="24">فرنسا</option><option value="25">إيطاليا</option><option value="26">إنجلترا</option><option value="27">ألمانيا</option><option value="28">إسبانيا</option><option value="29">هولندا</option><option value="30">البرتغال</option><option value="31">البرازيل</option><option value="32">روسيا</option><option value="33">اليابان</option><option value="34">الهند</option><option value="35">الصين</option><option value="36">باكستان</option><option value="37">كردستان</option><option value="38">إندونيسيا</option><option value="39">إيران</option>
                            </select>
                        </div>

                        <div class="input-group">
                            <label>الجنس</label>
                            <div class="radio-group-container">
                                <label><input type="radio" name="profile_field_16_-7" value="1" checked="checked" /> ذكر</label>
                                <label><input type="radio" name="profile_field_16_-7" value="2" /> انثى</label>
                                <label><input type="radio" name="profile_field_16_-7" value="3" /> أخرى</label>
                            </div>
                        </div>

                        <div class="input-group">
                            <label>تاريخ الميلاد</label>
                            <div class="dob-container">
                                <select name="profile_field_4_-12[]" required title="اليوم" style=" height: 38px; min-height: 38px; max-height: 38px; ">
                                    <option value="">يوم</option>
                                    <option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option>
                                </select>
                                <select name="profile_field_4_-12[]" required title="الشهر" style=" height: 38px; min-height: 38px; max-height: 38px; ">
                                    <option value="">شهر</option>
                                    <option value="1">يناير</option><option value="2">فبراير</option><option value="3">مارس</option><option value="4">أبريل</option><option value="5">مايو</option><option value="6">يونيو</option><option value="7">يوليو</option><option value="8">أغسطس</option><option value="9">سبتمبر</option><option value="10">أكتوبر</option><option value="11">نوفمبر</option><option value="12">ديسمبر</option>
                                </select>
                                <input type="text" name="profile_field_4_-12[]" maxlength="4" style=" height: 38px; min-height: 38px; max-height: 38px; " required placeholder="العام (1990)" title="العام" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="terms-group" style="margin-top: 10px; margin-bottom: 20px; text-align:center;">
                    <label style="cursor:pointer; color:#64748b; font-size:0.9rem; font-weight:600;">
                        <input type="checkbox" name="wantsnews" value="1" style="accent-color:#6366f1;" /> 
                        أوافق على القوانين وتلقي أخبار المنتدى
                    </label>
                </div>

                <button type="submit" name="submit" value="سجّل" class="submit-auth-btn">
                    متابعة التسجيل وإثبات الأمان <i class="fas fa-arrow-left"></i>
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function switchAuthTab(tab) {
    document.getElementById('tab-login').classList.remove('active');
    document.getElementById('tab-register').classList.remove('active');
    document.getElementById('tab-' + tab).classList.add('active');

    document.getElementById('form-login').classList.remove('active');
    document.getElementById('form-register').classList.remove('active');
    document.getElementById('form-' + tab).classList.add('active');

    var authBox = document.getElementById('authBoxContainer');
    if (tab === 'register') {
        authBox.classList.add('wide-modal');
    } else {
        authBox.classList.remove('wide-modal');
    }
}
</script>
<!-- END switch_user_logged_out -->
  
  

    <div class="search-overlay" id="searchModal">
        <div class="search-box">
            <div class="search-header">
                <h3><i class="fas fa-search" style="color: var(--primary-color);"></i> ابحث في المنتدى</h3>
                <button class="close-search" onclick="closeSearch()"><i class="fas fa-times"></i></button>
            </div>
            <div class="search-input-wrapper">
                <form action="/search" method="get" id="forumSearchForm" style="width: 100%; display: flex; align-items: center;">
                    <i class="fas fa-search" onclick="document.getElementById('forumSearchForm').submit();" style="cursor: pointer;"></i>
                    <input type="text" name="search_keywords" id="searchInput" placeholder="اكتب كلمة البحث هنا واضغط Enter..." onkeyup="performSearch()" />
                </form>
            </div>
            <div class="search-results" id="searchResults">
                <div class="search-placeholder">قم بكتابة حرفين على الأقل لبدء البحث...</div>
            </div>
        </div>
    </div>

    

    <div id="settingsPanel" class="settings-sidebar">
        <div class="sidebar-header">
            <i class="fas fa-times close-btn" onclick="toggleMenu('settingsPanel')"></i>
            <h3><i class="fas fa-paint-brush"></i> تخصيص المظهر</h3>
        </div>
        

        <div class="setting-section">
            <h4><i class="fas fa-th-large"></i> شكل عرض الأقسام</h4>
            <div class="theme-modes layout-modes">
                <button class="theme-btn active-btn" data-layout="list" onclick="setForumLayout('list', this)"><i class="fas fa-bars"></i> قائمة</button>
                <button class="theme-btn" data-layout="grid" onclick="setForumLayout('grid', this)"><i class="fas fa-th"></i> شبكة (بطاقات)</button>
            </div>
        </div>

        <div class="setting-section">
            <h4><i class="fas fa-text-height"></i> حجم الخط (الأساسي)</h4>
            <div class="font-counter-ui">
                <button onclick="changeFontSize(-1)"><i class="fas fa-minus"></i></button>
                <span id="fontSizeDisplay">16</span>
                <button onclick="changeFontSize(1)"><i class="fas fa-plus"></i></button>
            </div>
        </div>

        <div class="setting-section" id="saFontSection">
            <h4><i class="fas fa-font"></i> نوع الخط</h4>
            <div class="theme-modes sa-font-grid" id="saFontOptions">
                <button class="theme-btn sa-font-btn active-btn" data-sa-font="default" onclick="saSetFont('default', this)"><span class="sa-f-name">افتراضي (تجوال)</span><span class="sa-f-prev">أبجد هوز Softara 2026</span></button>
                <button class="theme-btn sa-font-btn" data-sa-font="cairo" onclick="saSetFont('cairo', this)"><span class="sa-f-name" style="font-family:'Cairo',sans-serif">كايرو</span><span class="sa-f-prev" style="font-family:'Cairo',sans-serif">أبجد هوز Softara 2026</span></button>
                <button class="theme-btn sa-font-btn" data-sa-font="tajawal" onclick="saSetFont('tajawal', this)"><span class="sa-f-name" style="font-family:'Tajawal',sans-serif">تجوال</span><span class="sa-f-prev" style="font-family:'Tajawal',sans-serif">أبجد هوز Softara 2026</span></button>
                <button class="theme-btn sa-font-btn" data-sa-font="almarai" onclick="saSetFont('almarai', this)"><span class="sa-f-name" style="font-family:'Almarai',sans-serif">المراعي</span><span class="sa-f-prev" style="font-family:'Almarai',sans-serif">أبجد هوز Softara 2026</span></button>
                <button class="theme-btn sa-font-btn" data-sa-font="ibmplex" onclick="saSetFont('ibmplex', this)"><span class="sa-f-name" style="font-family:'IBM Plex Sans Arabic',sans-serif">بلكس عربي</span><span class="sa-f-prev" style="font-family:'IBM Plex Sans Arabic',sans-serif">أبجد هوز Softara 2026</span></button>
                <button class="theme-btn sa-font-btn" data-sa-font="notokufi" onclick="saSetFont('notokufi', this)"><span class="sa-f-name" style="font-family:'Noto Kufi Arabic',sans-serif">نوتو كوفي</span><span class="sa-f-prev" style="font-family:'Noto Kufi Arabic',sans-serif">أبجد هوز Softara 2026</span></button>
                <button class="theme-btn sa-font-btn" data-sa-font="reemkufi" onclick="saSetFont('reemkufi', this)"><span class="sa-f-name" style="font-family:'Reem Kufi',sans-serif">ريم كوفي</span><span class="sa-f-prev" style="font-family:'Reem Kufi',sans-serif">أبجد هوز Softara 2026</span></button>
                <button class="theme-btn sa-font-btn" data-sa-font="amiri" onclick="saSetFont('amiri', this)"><span class="sa-f-name" style="font-family:'Amiri',serif">الأميري</span><span class="sa-f-prev" style="font-family:'Amiri',serif">أبجد هوز Softara 2026</span></button>
            </div>
        </div>
        
        <div class="setting-section">
            <h4><i class="fas fa-adjust"></i> وضع الشاشة</h4>
            <div class="theme-modes">
                <button class="theme-btn active-btn" data-theme="light" onclick="setSetting('theme', 'light', this)"><i class="fas fa-sun" style="color: #f59e0b;"></i> فاتح</button>
                <button class="theme-btn" data-theme="dark" onclick="setSetting('theme', 'dark', this)"><i class="fas fa-moon" style="color: #3b82f6;"></i> داكن</button>
            </div>
        </div>
        
        <div class="setting-section">
            <h4><i class="fas fa-palette"></i> لون المنتدى (16 لون)</h4>
            <div class="color-palette">

                <div class="color-circle" style="background: #e91e63;" data-color="#e91e63" onclick="setSetting('color', '#e91e63', this)"></div>
                <div class="color-circle" style="background: #f43f5e;" data-color="#f43f5e" onclick="setSetting('color', '#f43f5e', this)"></div>
                <div class="color-circle" style="background: #f97316;" data-color="#f97316" onclick="setSetting('color', '#f97316', this)"></div>
                <div class="color-circle" style="background: #eab308;" data-color="#eab308" onclick="setSetting('color', '#eab308', this)"></div>
                <div class="color-circle" style="background: #84cc16;" data-color="#84cc16" onclick="setSetting('color', '#84cc16', this)"></div>
                <div class="color-circle" style="background: #10b981;" data-color="#10b981" onclick="setSetting('color', '#10b981', this)"></div>
                <div class="color-circle" style="background: #14b8a6;" data-color="#14b8a6" onclick="setSetting('color', '#14b8a6', this)"></div>
                <div class="color-circle" style="background: #06b6d4;" data-color="#06b6d4" onclick="setSetting('color', '#06b6d4', this)"></div>
                <div class="color-circle" style="background: #0ea5e9;" data-color="#0ea5e9" onclick="setSetting('color', '#0ea5e9', this)"></div>
                <div class="color-circle" style="background: #3b82f6;" data-color="#3b82f6" onclick="setSetting('color', '#3b82f6', this)"></div>
                <div class="color-circle active-btn" style="background: #8b5cf6;" data-color="#8b5cf6" onclick="setSetting('color', '#8b5cf6', this)"></div>
                <div class="color-circle" style="background: #a855f7;" data-color="#a855f7" onclick="setSetting('color', '#a855f7', this)"></div>
                <div class="color-circle" style="background: #d946ef;" data-color="#d946ef" onclick="setSetting('color', '#d946ef', this)"></div>
                <div class="color-circle" style="background: #475569;" data-color="#475569" onclick="setSetting('color', '#475569', this)"></div>
                <div class="color-circle" style="background: #334155;" data-color="#334155" onclick="setSetting('color', '#334155', this)"></div>
                <div class="color-circle" style="background: #1e293b;" data-color="#1e293b" onclick="setSetting('color', '#1e293b', this)"></div>
            </div>
        </div>
        
        <div class="setting-section">
            <h4><i class="fas fa-image"></i> صورة الهيدر (تقنية وبرمجة)</h4>
            <div class="header-images">
                <div class="img-option no-img" data-img="none" onclick="setSetting('header', 'none', this)">بدون صورة</div>
                <div class="img-option active-btn" style="background-image: url('https://i.servimg.com/u/f88/18/93/95/45/profit11.jpg?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60');" data-img="url('https://i.servimg.com/u/f88/18/93/95/45/profit11.jpg')" onclick="setSetting('header', this.dataset.img, this)"></div>

                <div class="img-option" style="background-image: url('https://i.servimg.com/u/f88/18/93/95/45/progra10.jpg?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60');" data-img="url('https://i.servimg.com/u/f88/18/93/95/45/progra10.jpg?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80')" onclick="setSetting('header', this.dataset.img, this)"></div>
                <div class="img-option" style="background-image: url('https://i.servimg.com/u/f88/18/93/95/45/slider10.png?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60');" data-img="url('https://i.servimg.com/u/f88/18/93/95/45/slider10.png?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80')" onclick="setSetting('header', this.dataset.img, this)"></div>
                <div class="img-option" style="background-image: url('https://i.servimg.com/u/f88/18/93/95/45/yooo-a11.jpg?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60');" data-img="url('https://i.servimg.com/u/f88/18/93/95/45/yooo-a11.jpg?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80')" onclick="setSetting('header', this.dataset.img, this)"></div>
                <div class="img-option" style="background-image: url('https://i.servimg.com/u/f88/18/93/95/45/oio-oo10.jpg?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60');" data-img="url('https://i.servimg.com/u/f88/18/93/95/45/oio-oo10.jpg?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80')" onclick="setSetting('header', this.dataset.img, this)"></div>
            </div>
        </div>
        <button class="reset-btn" onclick="resetSettings()"><i class="fas fa-undo"></i> استعادة الوضع الافتراضي</button>
    </div>


    <nav class="navbar">
        <div class="container nav-content">
            <div class="logo"><i class="fas fa-layer-group"></i> <a id="logo-link" href="{U_INDEX}">{L_INDEX}</a>
          
          
          

                <ul class="main-menu" id="mainMenu">
                    <li><a href="/"><i class="fas fa-home"></i> الرئيسية</a></li>
                  
                    <li><a href="javascript:void(0);" onclick="openQuranPlayer(); return false;" title="مشغل القرآن الكريم - استماع مباشر"><i class="fas fa-mosque"></i> القرآن الكريم</a></li>
                    
                    <li><a href="/memberlist"><i class="fas fa-star"></i> الأعضاء</a></li>

                    <li class="has-dropdown">
                        <a href="javascript:void(0);"><i class="fas fa-th-large"></i> الأقسام <i class="fas fa-chevron-down arrow-icon"></i></a>
                        <ul class="sub-menu">
                            <li><a href="/f29-%D8%AA%D8%B7%D9%88%D9%8A%D8%B1-%D8%A7%D9%84%D9%85%D9%86%D8%AA%D8%AF%D9%8A%D8%A7%D8%AA-%D9%88%D8%A7%D9%84%D9%85%D9%88%D8%A7%D9%82%D8%B9"><i class="fas fa-laptop-code"></i> تصميم المواقع والمنتديات</a></li>
                            <li><a href="/h19-library"><i class="fas fa-book-open"></i> المكتبة الرقمية</a></li>
                            <li><a href="/f18-%D8%A7%D9%84%D8%AA%D8%B7%D8%A8%D9%8A%D9%82%D8%A7%D8%AA-%D9%88%D8%A7%D9%84%D8%A3%D9%84%D8%B9%D8%A7%D8%A8"><i class="fas fa-mobile-alt"></i> تطبيقات الهواتف الذكية</a></li>
                        </ul>
                    </li>
                    
                  <!-- BEGIN switch_user_logged_in -->

                    <li class="has-dropdown">
                        <a href="javascript:void(0);"><i class="fas fa-link"></i> روابط هامة <i class="fas fa-chevron-down arrow-icon"></i></a>
                        <ul class="sub-menu">
                            <li><a href="/search?search_id=newposts"><i class="fas fa-comment-dots"></i> المشاركات الجديدة</a></li>
                            <li><a href="/profile?mode=editprofile"><i class="fas fa-shield-alt"></i> لوحة التحكم</a></li>
                        </ul>
                    </li>
                    <!-- END switch_user_logged_in -->
                </ul>
          
          </div>
          
          
          
            <div class="nav-icons">
                <button type="button" class="icon-btn hamburger-menu-btn" id="menuToggleBtn" aria-label="فتح القائمة" aria-expanded="false" onclick="toggleMainMenu()"><i class="fas fa-bars"></i></button>
                <button class="icon-btn" onclick="openSearch()"><i class="fas fa-search"></i></button>
                <button class="icon-btn" onclick="toggleMenu('settingsPanel')"><i class="fas fa-paint-brush"></i></button>

                <!-- BEGIN switch_user_logged_out -->

                <div class="auth-buttons-group">
                    <button class="login-nav-btn" onclick="openAuthModal('login')">
                        <i class="fas fa-sign-in-alt"></i> <span>تسجيل الدخول</span>
                    </button>
                    <button class="register-nav-btn" onclick="openAuthModal('register')">
                        <i class="fas fa-user-plus"></i> <span>حساب جديد</span>
                    </button>
                </div>
                <!-- END switch_user_logged_out -->

                <!-- BEGIN switch_user_logged_in -->

                <button class="icon-btn" onclick="toggleMenu('notificationsBox')" id="customNotifBtn">
                    <i class="fas fa-bell"></i><span class="badge" id="customNotifBadge" style="display:none;">0</span>
                </button>
                <button class="user-avatar-btn" onclick="toggleMenu('userDropdown')">
                  <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 40'><circle cx='20' cy='20' r='20' fill='%23c7d2fe'></circle><circle cx='20' cy='15' r='7' fill='%236366f1'></circle><path d='M6 36c2-8 8-11 14-11s12 3 14 11z' fill='%236366f1'></path></svg>" id="customUserAvatar" alt="Avatar"/>
                </button>
                <!-- END switch_user_logged_in -->
            </div>

            <!-- BEGIN switch_user_logged_in -->

            <div id="notificationsBox" class="dropdown-panel">
                <div class="notif-header">الإشعارات الأخيرة</div>
                <div class="notif-list" id="customNotifList">
                    <div class="notif-item">جاري تحميل الإشعارات... <i class="fas fa-spinner fa-spin"></i></div>
                </div>
                <div class="dropdown-footer" style="text-align:center;"><a href="/profile?mode=editprofile&page_profil=notifications" style="font-size:12px;">عرض كل الإشعارات</a></div>
            </div>

            <div id="userDropdown" class="dropdown-panel">
    <div class="dropdown-header-box" id="profileHeaderBox">
      <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 40'><circle cx='20' cy='20' r='20' fill='%23c7d2fe'></circle><circle cx='20' cy='15' r='7' fill='%236366f1'></circle><path d='M6 36c2-8 8-11 14-11s12 3 14 11z' fill='%236366f1'></path></svg>" id="customUserAvatarLarge" alt="Avatar"/>
        <div style="display:flex; flex-direction:column; align-items:center; gap:5px; margin-top: 10px;">
            <h3 id="customUserName" style="margin:0; font-weight:bold;">اسم العضو</h3>

            <div id="customUserRankBox" style="display:flex; flex-direction:column; align-items:center; gap:6px;">
                <span id="customUserRankText" class="user-rank-badge" style="display:none;"></span>
                <img id="customUserRankImg" src="" style="display:none;" alt="Rank"/>
            </div>
        </div>
    </div>
    <ul class="dropdown-menu-list">
        <li><a href="/profile?mode=editprofile" id="customProfileLink"><span>الملف الشخصي</span> <i class="fas fa-user"></i></a></li>
        <li><a href="/profile?mode=editprofile"><span>تعديل البيانات</span> <i class="fas fa-user-edit"></i></a></li>

        <li>
            <a href="{U_PRIVATEMSGS}">
                <span id="pmText">الرسائل الخاصة</span> 
                <div class="pm-icon-wrapper">
                    <i class="fas fa-envelope"></i>
                    <span id="customPmBadge" class="pm-dropdown-badge">0</span>
                </div>
            </a>
        </li>
        <li><a href="/search?search_id=egosearch"><span>مواضيعي ومشاركاتي</span> <i class="fas fa-list-alt"></i></a></li>
    </ul>
    <div class="dropdown-footer"><a href="{U_LOGIN_LOGOUT}"><span>تسجيل الخروج</span> <i class="fas fa-sign-out-alt"></i></a></div>
</div>
            <script type="text/javascript">
            //<![CDATA[
            /* ربط رابط "الملف الشخصي" في القائمة المنسدلة بصفحة العضو الحقيقية /uID */
            (function () {
                function setProfileLink() {
                    var link = document.getElementById('customProfileLink');
                    if (!link) { return; }
                    if (typeof _userdata !== 'undefined' && _userdata.user_id && parseInt(_userdata.user_id, 10) > 0) {
                        link.href = '/u' + _userdata.user_id;
                    }
                }
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', setProfileLink);
                } else {
                    setProfileLink();
                }
            })();
            //]]>
            </script>
            <!-- END switch_user_logged_in -->

        </div>
    </nav>


    <header class="main-header" id="mainHeader">
        <div class="container"><h2 class="main-header-title">أهلاً بك في <a href="{U_INDEX}">{L_INDEX}</a></h2></div>
    </header>

    <!-- ===== مشغل القرآن الكريم - سوفتارا (يعمل بدون تسجيل دخول) ===== -->
    <div class="quran-overlay" id="quranModal" dir="rtl" lang="ar">
        <div class="quran-box">
            <button type="button" class="quran-close" onclick="closeQuranPlayer()" title="إغلاق"><i class="fas fa-times"></i></button>
            <h3><i class="fas fa-mosque"></i> مكتبة القرآن الكريم - سوفتارا</h3>
            <div class="quran-sub">استماع مباشر بجودة عالية — اختر القارئ والسورة</div>
            <div class="quran-field">
                <label for="quranReciter"><i class="fas fa-user"></i> القارئ</label>
                <div class="select"><select id="quranReciter" onchange="quranSelectionChanged()"></select></div>
            </div>
            <div class="quran-field">
                <label for="quranSurah"><i class="fas fa-book-open"></i> السورة</label>
                <div class="select"><select id="quranSurah" onchange="quranSelectionChanged()"></select></div>
            </div>
            <div class="quran-now" id="quranNowPlaying"></div>
            <div class="quran-audio-wrap">
                <audio id="quranAudio" controls preload="none"></audio>
            </div>
            <div class="quran-nav-btns">
                <button type="button" onclick="quranStep(1)" title="السورة التالية"><i class="fas fa-forward"></i> التالية</button>
                <button type="button" id="quranRadioBtn" onclick="toggleQuranRadio()" title="راديو القرآن المباشر"><i class="fas fa-broadcast-tower"></i> <span>راديو مباشر</span></button>
                <button type="button" class="q-secondary" onclick="quranStep(-1)" title="السورة السابقة"><i class="fas fa-backward"></i> السابقة</button>
            </div>
            <div class="quran-hint">عند انتهاء السورة ينتقل المشغل تلقائياً إلى السورة التالية — المصدر: mp3quran.net</div>
            <div class="quran-designer-credit">
                <a href="https://almoatn.blogspot.com" target="_blank" rel="noopener" class="designer-name">تصميم وبرمجة عوض السوداني</a>
                <div class="sadaqa-jaria">صدقة جارية لي ولوالدي وللمسلمين</div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/gh/softara1/softara@ec48fc7f/up/softara-quran.js"></script>

    
    <main class="container">
    <!-- BEGIN html_validation -->
    </main>


    <!-- BEGIN switch_user_logged_in -->
    <script type="text/javascript">

    </script>
    <!-- END switch_user_logged_in -->

</body>
</html>
<!-- END html_validation -->